'use client';
import dynamic from 'next/dynamic';
import React from 'react';

const Sidebar = dynamic(() => import('@/components/Sidebar'), { ssr: false });
const TopBar = dynamic(() => import('@/components/TopBar'), { ssr: false });

export default function ClientShell({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Sidebar />
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <TopBar />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-transparent p-4 md:p-8">
          {children}
        </main>
      </div>
    </>
  );
}
