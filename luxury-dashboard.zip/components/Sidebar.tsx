"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  PackageSearch,
  Settings,
  Users,
  ShoppingCart,
  ShoppingBag,
  BarChart3,
  Bell,
  Search,
  Menu,
  MessageCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

const navItems = [
  { name: "الرئيسية", href: "/", icon: LayoutDashboard },
  { name: "إدارة المنتجات", href: "/products", icon: PackageSearch },
  { name: "الطلبات", href: "/orders", icon: ShoppingCart },
  { name: "السلات المتروكة", href: "/abandoned-carts", icon: ShoppingBag },
  { name: "العملاء", href: "/customers", icon: Users },
  { name: "مركز المحادثات", href: "/chat", icon: MessageCircle },
  { name: "التقارير", href: "/reports", icon: BarChart3 },
  { name: "الإعدادات", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed md:static inset-y-0 right-0 z-50 w-64 bg-white border-l border-slate-200 transition-transform duration-300 ease-in-out md:translate-x-0 shadow-xl flex flex-col",
          isOpen ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="p-8 flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-amber-400 to-amber-600 rounded-xl shadow-lg shadow-amber-200 flex items-center justify-center">
            <span className="text-white font-bold text-xl uppercase">ل</span>
          </div>
          <span className="font-bold text-xl tracking-tight text-slate-800 uppercase">
            لوكسري
          </span>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4 custom-scrollbar overflow-y-auto">
          {navItems.map((item) => {
            const isActive =
              pathname === item.href ||
              (item.href !== "/" && pathname.startsWith(item.href));
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "flex items-center gap-4 px-4 py-3 rounded-xl transition-colors duration-200 group relative overflow-hidden",
                  isActive
                    ? "bg-slate-50 text-amber-600 font-semibold"
                    : "text-slate-500 hover:bg-slate-50 hover:text-slate-700",
                )}
              >
                <Icon
                  className={cn(
                    "w-5 h-5 transition-colors duration-200",
                    isActive
                      ? "text-amber-600"
                      : "text-slate-500 group-hover:text-slate-600",
                  )}
                />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-6">
          <div className="bg-amber-50 rounded-2xl p-4 border border-amber-100">
            <p className="text-xs font-bold text-amber-800 uppercase">
              خطة البريميوم
            </p>
            <p className="text-[10px] text-amber-600 mt-1">
              استمتع بكافة الميزات الفاخرة المتاحة
            </p>
            <button className="mt-3 w-full bg-amber-600 hover:bg-amber-700 text-white text-xs py-2 rounded-lg font-bold shadow-md shadow-amber-200 transition-colors">
              ترقية الآن
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
