"use client";
import { Bell, Search, Menu } from "lucide-react";
import Image from "next/image";

export default function TopBar() {
  return (
    <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-4">
        <button className="md:hidden p-2 -ml-2 text-slate-500 hover:text-slate-800 transition-colors">
          <Menu className="w-6 h-6" />
        </button>

        <div className="hidden md:flex items-center relative">
          <Search className="w-5 h-5 text-slate-400 absolute right-4" />
          <input
            type="text"
            placeholder="ابحث عن منتج، طلب، أو عميل..."
            className="pl-4 pr-12 py-2.5 bg-slate-50 border-transparent focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-500 w-80 rounded-full text-sm transition-all outline-none"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative w-10 h-10 rounded-full border border-slate-100 flex items-center justify-center bg-white text-slate-500 hover:text-slate-800 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 left-2 w-2 h-2 bg-rose-500 rounded-full border border-white"></span>
        </button>
        <div className="hidden md:flex items-center gap-3 pr-4 border-r border-slate-200">
          <div className="text-left text-xs leading-tight">
            <p className="font-bold text-slate-800">أحمد محمد</p>
            <p className="text-slate-400">مدير النظام</p>
          </div>
          <Image
            src="https://i.pravatar.cc/150?img=11"
            width={40}
            height={40}
            alt="User"
            className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm"
            referrerPolicy="no-referrer"
            unoptimized
          />
        </div>
      </div>
    </header>
  );
}
