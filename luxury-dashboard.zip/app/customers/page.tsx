"use client";

import React, { useState } from "react";

import Link from "next/link";

import { MOCK_CUSTOMERS } from "./mock-data";

import {
  Search,
  ListFilter,
  Smartphone,
  Monitor,
  Instagram,
  Facebook,
  Globe,
  Link2,
  MoreVertical,
  Eye,
} from "lucide-react";

import { Input } from "@/components/ui/input";

import { Button } from "@/components/ui/button";

import { Customer, AcquisitionSource } from "./types";

const SourceIcon = ({
  source,
  className,
}: {
  source: AcquisitionSource;
  className?: string;
}) => {
  switch (source) {
    case "instagram":
      return <Instagram className={className} />;

    case "facebook":
      return <Facebook className={className} />;

    case "tiktok":
      return <div className={`font-bold italic ${className}`}>TikTok</div>;
    // Or custom SVG
    case "google":
      return <Globe className={className} />;

    default:
      return <Link2 className={className} />;
  }
};

const SourceLabel = ({ source }: { source: AcquisitionSource }) => {
  const map: Record<AcquisitionSource, string> = {
    direct: "مباشر",
    facebook: "فيسبوك",
    instagram: "انستجرام",
    tiktok: "تيك توك",
    google: "جوجل",
    snapchat: "سناب شات",
  };

  return <span>{map[source]}</span>;
};

export default function CustomersPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCustomers = MOCK_CUSTOMERS.filter(
    (c) =>
      c.phone.includes(searchTerm) ||
      (c.name && c.name.includes(searchTerm)) ||
      c.ipAddress.includes(searchTerm),
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
            العملاء والزوار
          </h1>
          <p className="text-slate-500 mt-1 text-sm">
            إدارة بيانات العملاء وتتبع سلوكهم في المتجر
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
        <div className="p-4 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="ابحث بالاسم، الجوال، أو الـ IP..."
              className="pr-9 h-11 rounded-xl bg-slate-50 border-slate-200 w-full focus-visible:ring-amber-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button
            variant="outline"
            className="h-11 rounded-xl px-4 w-full sm:w-auto gap-2 text-slate-600 border-slate-200"
          >
            <ListFilter className="w-4 h-4" />
            <span className="font-semibold">تصفية</span>
          </Button>
        </div>

        <div className="overflow-x-auto w-full">
          <table className="w-full min-w-[800px] text-sm text-right">
            <thead className="bg-slate-50/50 text-slate-500 font-semibold border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 whitespace-nowrap">العميل / الجوال</th>
                <th className="px-6 py-4 whitespace-nowrap">الـ IP / الجهاز</th>
                <th className="px-6 py-4 whitespace-nowrap">المصدر</th>
                <th className="px-6 py-4 whitespace-nowrap text-center">
                  إجمالي الطلبات
                </th>
                <th className="px-6 py-4 whitespace-nowrap text-center">
                  المدفوعات
                </th>
                <th className="px-6 py-4 whitespace-nowrap">آخر ظهور</th>
                <th className="px-6 py-4 whitespace-nowrap text-center">
                  الإجراءات
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-6 py-12 text-center text-slate-500"
                  >
                    لا يوجد عملاء يطابقون بحثك
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((customer) => (
                  <tr
                    key={customer.id}
                    className="hover:bg-slate-50/50 transition-colors"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-800">
                          {customer.name || "غير مسجل (زائر)"}
                        </span>
                        <span
                          className="text-slate-500 text-xs mt-0.5"
                          dir="ltr"
                        >
                          {customer.phone}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="font-medium text-slate-700 font-mono text-xs">
                          {customer.ipAddress}
                        </span>
                        <span className="text-slate-500 text-xs mt-0.5 flex items-center gap-1">
                          {customer.device.includes("iPhone") ||
                          customer.device.includes("Galaxy") ? (
                            <Smartphone className="w-3 h-3" />
                          ) : (
                            <Monitor className="w-3 h-3" />
                          )}
                          {customer.device}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-md bg-slate-100 flex items-center justify-center text-slate-600">
                          <SourceIcon
                            source={customer.source}
                            className="w-3.5 h-3.5"
                          />
                        </div>
                        <span className="text-slate-600 font-medium text-xs">
                          <SourceLabel source={customer.source} />
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className={`inline-flex items-center justify-center min-w-[2rem] h-6 rounded-full text-xs font-bold ${customer.totalOrders > 0 ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"}`}
                      >
                        {customer.totalOrders}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className="font-bold text-slate-800">
                        {customer.totalSpent > 0
                          ? `${customer.totalSpent.toLocaleString()} ر.س`
                          : "-"}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="text-slate-700 font-medium">
                          {new Date(customer.lastSeen).toLocaleDateString(
                            "ar-EG",
                          )}
                        </span>
                        <span className="text-slate-500 text-xs">
                          {new Date(customer.lastSeen).toLocaleTimeString(
                            "ar-EG",
                          )}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-2">
                        <Link href={`/customers/${customer.id}`}>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}


