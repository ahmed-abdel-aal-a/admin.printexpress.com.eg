export type AcquisitionSource = 'direct' | 'facebook' | 'instagram' | 'tiktok' | 'google' | 'snapchat';

export interface BrowsingEvent {
  id: string;
  path: string;
  title: string;
  timestamp: string;
  type: 'enter' | 'view' | 'exit' | 'add_to_cart' | 'checkout' | 'purchase';
}

export interface Customer {
  id: string;
  name: string | null;
  phone: string;
  email: string | null;
  ipAddress: string;
  source: AcquisitionSource;
  totalOrders: number;
  totalSpent: number;
  lastSeen: string;
  firstSeen: string;
  device: string;
  browsingHistory: BrowsingEvent[];
}
