import { Customer } from './types';

export const MOCK_CUSTOMERS: Customer[] = [
  {
    id: 'CUST-001',
    name: 'أحمد محمود',
    phone: '+966 50 123 4567',
    email: 'ahmed@example.com',
    ipAddress: '192.168.1.105',
    source: 'instagram',
    totalOrders: 3,
    totalSpent: 1450,
    lastSeen: '2024-05-20T14:30:00Z',
    firstSeen: '2024-01-15T09:00:00Z',
    device: 'iPhone 14 Pro - Safari',
    browsingHistory: [
      { id: '1', path: '/', title: 'الصفحة الرئيسية', timestamp: '2024-05-20T14:00:00Z', type: 'enter' },
      { id: '2', path: '/products/perfume-oud', title: 'عطر عود ملكي', timestamp: '2024-05-20T14:05:00Z', type: 'view' },
      { id: '3', path: '/products/perfume-oud', title: 'عطر عود ملكي', timestamp: '2024-05-20T14:10:00Z', type: 'add_to_cart' },
      { id: '4', path: '/checkout', title: 'الدفع', timestamp: '2024-05-20T14:15:00Z', type: 'checkout' },
      { id: '5', path: '/thank-you', title: 'تأكيد الطلب', timestamp: '2024-05-20T14:20:00Z', type: 'purchase' },
      { id: '6', path: '/thank-you', title: 'تأكيد الطلب', timestamp: '2024-05-20T14:30:00Z', type: 'exit' },
    ]
  },
  {
    id: 'CUST-002',
    name: null,
    phone: '+966 55 987 6543',
    email: null,
    ipAddress: '45.12.33.10',
    source: 'tiktok',
    totalOrders: 1,
    totalSpent: 299,
    lastSeen: '2024-05-19T20:15:00Z',
    firstSeen: '2024-05-19T19:50:00Z',
    device: 'Samsung Galaxy S23 - Chrome',
    browsingHistory: [
      { id: '1', path: '/campaign/summer-sale', title: 'عروض الصيف', timestamp: '2024-05-19T19:50:00Z', type: 'enter' },
      { id: '2', path: '/products/watch-silver', title: 'ساعة فضية', timestamp: '2024-05-19T19:55:00Z', type: 'view' },
      { id: '3', path: '/checkout', title: 'الدفع', timestamp: '2024-05-19T20:05:00Z', type: 'checkout' },
      { id: '4', path: '/thank-you', title: 'تأكيد الطلب', timestamp: '2024-05-19T20:15:00Z', type: 'exit' },
    ]
  },
  {
    id: 'CUST-003',
    name: 'سارة خالد',
    phone: '+966 54 321 0987',
    email: 'sara.k@example.com',
    ipAddress: '37.43.120.55',
    source: 'facebook',
    totalOrders: 0,
    totalSpent: 0,
    lastSeen: '2024-05-21T10:00:00Z',
    firstSeen: '2024-05-21T09:45:00Z',
    device: 'iPad Pro - Safari',
    browsingHistory: [
      { id: '1', path: '/', title: 'الصفحة الرئيسية', timestamp: '2024-05-21T09:45:00Z', type: 'enter' },
      { id: '2', path: '/category/bags', title: 'الحقائب', timestamp: '2024-05-21T09:50:00Z', type: 'view' },
      { id: '3', path: '/category/bags', title: 'الحقائب', timestamp: '2024-05-21T10:00:00Z', type: 'exit' },
    ]
  }
];
