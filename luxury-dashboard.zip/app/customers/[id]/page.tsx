import React from "react";

import Link from "next/link";

import { notFound } from "next/navigation";

import { MOCK_CUSTOMERS } from "../mock-data";

import {
  ArrowRight,
  User,
  Phone,
  Mail,
  Globe,
  MapPin,
  Smartphone,
  Monitor,
  ShoppingBag,
  Clock,
  ArrowRightLeft,
  LogIn,
  LogOut,
  Search,
  CreditCard,
  CheckCircle2,
} from "lucide-react";

import { Button } from "@/components/ui/button";

const EventIcon = ({ type }: { type: string }) => {
  switch (type) {
    case "enter":
      return <LogIn className="w-4 h-4 text-emerald-500" />;

    case "view":
      return <Search className="w-4 h-4 text-blue-500" />;

    case "add_to_cart":
      return <ShoppingBag className="w-4 h-4 text-amber-500" />;

    case "checkout":
      return <CreditCard className="w-4 h-4 text-indigo-500" />;

    case "purchase":
      return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;

    case "exit":
      return <LogOut className="w-4 h-4 text-rose-500" />;

    default:
      return <ArrowRightLeft className="w-4 h-4 text-slate-400" />;
  }
};

const EventLabel = ({ type }: { type: string }) => {
  switch (type) {
    case "enter":
      return "دخول للمتجر";

    case "view":
      return "تصفح صفحة";

    case "add_to_cart":
      return "إضافة للسلة";

    case "checkout":
      return "بدء الدفع";

    case "purchase":
      return "إتمام الطلب";

    case "exit":
      return "خروج";

    default:
      return "نشاط";
  }
};

// Next.js 15+ async params
export default function CustomerDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  // Use React.use() to unwrap params if needed in strict mode, but standard destructuring works in most setups.
  // Next 15 prefers React.use(params). Let's unwrap safely.
  const resolvedParams = React.use(params);

  const { id } = resolvedParams;

  const customer = MOCK_CUSTOMERS.find((c) => c.id === id);

  if (!customer) {
    notFound();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/customers">
          <Button
            variant="outline"
            size="icon"
            className="h-10 w-10 rounded-xl bg-white border-slate-200"
          >
            <ArrowRight className="w-4 h-4 text-slate-600" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
            تفاصيل العميل
          </h1>
          <p className="text-slate-500 mt-1 text-sm font-mono">{customer.id}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Customer Profile Card */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-50 to-transparent rounded-bl-full -z-0 opacity-50"></div>

            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-24 h-24 bg-gradient-to-tr from-blue-100 to-indigo-50 rounded-full flex items-center justify-center border-4 border-white shadow-sm mb-4">
                <User className="w-10 h-10 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold text-slate-800">
                {customer.name || "زائر غير مسجل"}
              </h2>
              <p className="text-slate-500 text-sm mt-1" dir="ltr">
                {customer.phone}
              </p>

              <div className="flex gap-2 mt-4">
                <span
                  className={`px-3 py-1 text-xs font-bold rounded-full ${customer.totalOrders > 0 ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-600"}`}
                >
                  {customer.totalOrders} طلبات
                </span>
                <span className="px-3 py-1 text-xs font-bold rounded-full bg-blue-50 text-blue-600">
                  {customer.totalSpent.toLocaleString()} ر.س
                </span>
              </div>
            </div>

            <div className="mt-8 space-y-4">
              <h3 className="text-sm font-bold text-slate-800 border-b border-slate-100 pb-2">
                بيانات التواصل
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-500">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 text-xs">رقم الجوال</span>
                    <span className="font-medium text-slate-800" dir="ltr">
                      {customer.phone}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 text-xs">
                      البريد الإلكتروني
                    </span>
                    <span className="font-medium text-slate-800">
                      {customer.email || "غير متوفر"}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 space-y-4">
              <h3 className="text-sm font-bold text-slate-800 border-b border-slate-100 pb-2">
                معلومات الجهاز والاتصال
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 text-xs">
                      عنوان IP (معرف العميل)
                    </span>
                    <span className="font-medium text-slate-800 font-mono">
                      {customer.ipAddress}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                    {customer.device.includes("iPhone") ||
                    customer.device.includes("Galaxy") ? (
                      <Smartphone className="w-4 h-4" />
                    ) : (
                      <Monitor className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 text-xs">
                      الجهاز المستخدم
                    </span>
                    <span className="font-medium text-slate-800">
                      {customer.device}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 text-xs">المصدر</span>
                    <span className="font-medium text-slate-800 uppercase">
                      {customer.source}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Browsing History */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 h-full">
            <div className="flex items-center justify-between mb-6 border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-800">
                  سجل التصفح والنشاط
                </h2>
                <p className="text-slate-500 text-sm mt-1">
                  تتبع مسار العميل داخل المتجر وتفاعلاته
                </p>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-400" />
                <span className="text-sm font-medium text-slate-600">
                  آخر ظهور:{" "}
                  {new Date(customer.lastSeen).toLocaleTimeString("ar-EG", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </div>

            <div className="relative pl-4 pr-6 sm:pr-8 border-r-2 border-slate-100 space-y-8 mt-8">
              {customer.browsingHistory.map((event, index) => (
                <div key={event.id} className="relative">
                  {/* Timeline dot */}
                  <div className="absolute -right-[35px] sm:-right-[43px] top-1 w-6 h-6 rounded-full bg-white border-2 border-slate-200 flex items-center justify-center z-10 shadow-sm">
                    <EventIcon type={event.type} />
                  </div>

                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 hover:border-slate-200 hover:shadow-sm transition-all duration-200">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800 text-sm">
                          <EventLabel type={event.type} />
                        </span>
                        {event.type === "purchase" && (
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-bold rounded-full">
                            ناجح
                          </span>
                        )}
                      </div>
                      <span
                        className="text-xs font-medium text-slate-500"
                        dir="ltr"
                      >
                        {new Date(event.timestamp).toLocaleString("ar-EG")}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-slate-500">الصفحة:</span>
                      <span className="font-semibold text-blue-600">
                        {event.title}
                      </span>
                      <span
                        className="text-xs text-slate-400 font-mono hidden sm:inline-block truncate max-w-[200px]"
                        dir="ltr"
                      >
                        {event.path}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Timeline Start Point */}
              <div className="relative pt-4">
                <div className="absolute -right-[31px] sm:-right-[39px] top-6 w-4 h-4 rounded-full bg-slate-200 border-2 border-white z-10"></div>
                <div className="text-sm font-medium text-slate-400 pr-2">
                  بداية الزيارة -{" "}
                  {new Date(customer.firstSeen).toLocaleString("ar-EG")}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function generateStaticParams() {
  return MOCK_CUSTOMERS.map((customer) => ({
    id: customer.id,
  }));
}
