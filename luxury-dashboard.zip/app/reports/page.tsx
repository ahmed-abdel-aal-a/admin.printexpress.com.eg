"use client";

import React, { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  TooltipProps,
} from "recharts";
import {
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  Calendar as CalendarIcon,
  MapPin,
  Award,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

// --- Types ---
export interface MonthlySalesData {
  month: string;
  revenue: number;
  orders: number;
}

export interface TopProduct {
  id: number;
  name: string;
  category: string;
  sales: number;
  revenue: number;
  trend: string;
  isUp: boolean;
}

export interface TopCustomer {
  id: number;
  name: string;
  email: string;
  orders: number;
  revenue: number;
  loyaltyTier: "Bronze" | "Silver" | "Gold" | "Platinum";
}

export interface CityData {
  id: string;
  name: string;
  value: number; // Percentage
  revenue: number;
  orders: number;
  growth: string;
  isUp: boolean;
}

export interface KPIStat {
  id: string;
  title: string;
  value: string;
  trend: string;
  isUp: boolean;
  icon: React.ElementType;
  color: string;
  bg: string;
}

// --- Mock Data (Ready for Backend) ---
const mockMonthlySalesData: MonthlySalesData[] = [
  { month: "يناير", revenue: 45000, orders: 120 },
  { month: "فبراير", revenue: 52000, orders: 135 },
  { month: "مارس", revenue: 48000, orders: 125 },
  { month: "أبريل", revenue: 61000, orders: 160 },
  { month: "مايو", revenue: 59000, orders: 150 },
  { month: "يونيو", revenue: 75000, orders: 190 },
  { month: "يوليو", revenue: 82000, orders: 210 },
  { month: "أغسطس", revenue: 85000, orders: 220 },
];

const mockTopSellingProducts: TopProduct[] = [
  { id: 1, name: "حقيبة جلدية فاخرة", category: "الحقائب", sales: 1240, revenue: 450000, trend: "+12%", isUp: true },
  { id: 2, name: "ساعة كلاسيكية", category: "الإكسسوارات", sales: 980, revenue: 320000, trend: "+8%", isUp: true },
  { id: 3, name: "عطر ليلي", category: "العطور", sales: 850, revenue: 210000, trend: "-3%", isUp: false },
  { id: 4, name: "محفظة رجالية", category: "الإكسسوارات", sales: 720, revenue: 115000, trend: "+15%", isUp: true },
  { id: 5, name: "نظارة شمسية", category: "الإكسسوارات", sales: 640, revenue: 95000, trend: "+5%", isUp: true },
];

const mockSalesByCity: CityData[] = [
  { id: "riyadh", name: "الرياض", value: 45, revenue: 560250, orders: 1552, growth: "+18%", isUp: true },
  { id: "jeddah", name: "جدة", value: 30, revenue: 373500, orders: 1035, growth: "+12%", isUp: true },
  { id: "dammam", name: "الدمام", value: 15, revenue: 186750, orders: 518, growth: "-2%", isUp: false },
  { id: "makkah", name: "مكة", value: 10, revenue: 124500, orders: 345, growth: "+5%", isUp: true },
];

const mockTopCustomers: TopCustomer[] = [
  { id: 1, name: "أحمد عبدالله", email: "ahmed@example.com", orders: 24, revenue: 18500, loyaltyTier: "Platinum" },
  { id: 2, name: "سارة خالد", email: "sara@example.com", orders: 18, revenue: 14200, loyaltyTier: "Gold" },
  { id: 3, name: "محمد فهد", email: "mohammed@example.com", orders: 15, revenue: 11800, loyaltyTier: "Gold" },
  { id: 4, name: "نورة سعود", email: "noura@example.com", orders: 12, revenue: 9500, loyaltyTier: "Silver" },
  { id: 5, name: "عمر طارق", email: "omar@example.com", orders: 8, revenue: 4600, loyaltyTier: "Bronze" },
];

const COLORS = ["#d97706", "#f59e0b", "#fbbf24", "#fcd34d"];

const KPIStats: KPIStat[] = [
  {
    id: "total-revenue",
    title: "إجمالي الإيرادات",
    value: "1,245,000 ر.س",
    trend: "+14.5%",
    isUp: true,
    icon: DollarSign,
    color: "text-emerald-600",
    bg: "bg-emerald-50",
  },
  {
    id: "total-orders",
    title: "إجمالي الطلبات",
    value: "3,450",
    trend: "+8.2%",
    isUp: true,
    icon: ShoppingCart,
    color: "text-blue-600",
    bg: "bg-blue-50",
  },
  {
    id: "avg-order-value",
    title: "متوسط قيمة الطلب",
    value: "360 ر.س",
    trend: "-2.4%",
    isUp: false,
    icon: TrendingUp,
    color: "text-amber-600",
    bg: "bg-amber-50",
  },
  {
    id: "new-customers",
    title: "العملاء الجدد",
    value: "842",
    trend: "+22.4%",
    isUp: true,
    icon: Users,
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
];

// Custom Tooltip for Recharts
const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string> & {
  active?: boolean;
  payload?: Array<{ color: string; name: string; value: number }>;
  label?: string;
}) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-4 rounded-xl shadow-xl border border-slate-100 text-right">
        <p className="font-bold text-slate-800 mb-2">{label}</p>
        {payload.map((entry, index: number) => (
          <p key={index} className="text-sm text-slate-600">
            <span
              className="inline-block w-3 h-3 rounded-full ml-2"
              style={{ backgroundColor: entry.color }}
            ></span>
            <span className="font-medium">
              {entry.name === "revenue" ? "الإيرادات: " : "الطلبات: "}
            </span>
            <span className="font-bold text-slate-800">
              {entry.value.toLocaleString()} {entry.name === "revenue" && "ر.س"}
            </span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

interface ReportDataState {
  sales: MonthlySalesData[];
  products: TopProduct[];
  cities: CityData[];
  customers: TopCustomer[];
}

export default function ReportsPage() {
  const [timeRange, setTimeRange] = useState("year");
  const [isLoading, setIsLoading] = useState(true);
  const [reportData, setReportData] = useState<ReportDataState>({
    sales: [],
    products: [],
    cities: [],
    customers: [],
  });

  // محاكاة جلب البيانات من الباك اند (Backend Data Fetching Simulation)
  React.useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    // محاكاة تأخير الشبكة
    const timer = setTimeout(() => {
      if (isMounted) {
        setReportData({
          sales: mockMonthlySalesData,
          products: mockTopSellingProducts,
          cities: mockSalesByCity,
          customers: mockTopCustomers,
        });
        setIsLoading(false);
      }
    }, 600);
    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [timeRange]);

  return (
    <div className="min-h-screen bg-[#FDFDFD] p-6 lg:p-8 font-sans relative" dir="rtl">
      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-50 bg-white/60 backdrop-blur-sm flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
            <span className="text-sm font-bold text-slate-600">جاري تحميل التقارير...</span>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight mb-1">
            التقارير التحليلية
          </h1>
          <p className="text-slate-500 font-medium text-sm">
            نظرة شاملة على أداء المبيعات والمنتجات
          </p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative group flex-1 sm:flex-none">
            <select
              value={timeRange}
              onChange={(e) => {
                setIsLoading(true);
                setTimeRange(e.target.value);
              }}
              className="w-full appearance-none bg-white border border-slate-200 text-slate-700 py-2.5 px-4 pr-10 rounded-xl shadow-sm outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all font-medium text-sm cursor-pointer"
            >
              <option value="today">اليوم</option>
              <option value="week">هذا الأسبوع</option>
              <option value="month">هذا الشهر</option>
              <option value="year">هذا العام</option>
            </select>
            <CalendarIcon className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
          <button className="flex-1 sm:flex-none bg-slate-900 hover:bg-slate-800 text-white py-2.5 px-5 rounded-xl shadow-lg shadow-slate-900/20 transition-all flex items-center justify-center gap-2 font-bold text-sm">
            <Download className="w-4 h-4" />
            <span>تصدير</span>
          </button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {KPIStats.map((stat) => (
          <div
            key={stat.id}
            className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group"
          >
            <div className="flex justify-between items-start mb-4">
              <div className={cn("p-3 rounded-xl", stat.bg)}>
                <stat.icon className={cn("w-6 h-6", stat.color)} />
              </div>
              <div
                className={cn(
                  "flex items-center gap-1 text-sm font-bold px-2 py-1 rounded-full",
                  stat.isUp
                    ? "text-emerald-700 bg-emerald-50"
                    : "text-rose-700 bg-rose-50"
                )}
              >
                {stat.isUp ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                )}
                {stat.trend}
              </div>
            </div>
            <div>
              <p className="text-slate-500 text-sm font-medium mb-1">
                {stat.title}
              </p>
              <h3 className="text-2xl font-black text-slate-800 tracking-tight">
                {stat.value}
              </h3>
            </div>
            {/* Decorative background accent */}
            <div
              className={cn(
                "absolute -right-6 -bottom-6 w-24 h-24 rounded-full opacity-0 group-hover:opacity-10 transition-opacity blur-2xl",
                stat.color.replace("text-", "bg-")
              )}
            />
          </div>
        ))}
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Revenue Trend Chart */}
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm lg:col-span-2 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                إيرادات المبيعات
              </h2>
              <p className="text-slate-500 text-sm font-medium">
                تحليل الإيرادات والطلبات خلال العام
              </p>
            </div>
            <div className="flex items-center gap-4 text-sm font-medium">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                <span className="text-slate-600">الإيرادات</span>
              </div>
            </div>
          </div>
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={reportData.sales}
                margin={{ top: 10, right: 0, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#f1f5f9"
                />
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#64748b", fontSize: 12, fontWeight: 500 }}
                  dy={10}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#64748b", fontSize: 12, fontWeight: 500 }}
                  dx={-10}
                  tickFormatter={(value) => `${value / 1000}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#f59e0b"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                  activeDot={{ r: 6, fill: "#b45309", stroke: "#fff", strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sales by City */}
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col">
          <div className="mb-6">
            <h2 className="text-lg font-bold text-slate-900">
              المبيعات حسب المدينة
            </h2>
            <p className="text-slate-500 text-sm font-medium">
              توزيع المبيعات في أبرز المدن
            </p>
          </div>
          <div className="flex-1 flex flex-col justify-center min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={reportData.cities}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {reportData.cities.map((entry, index) => (
                    <Cell
                      key={entry.id}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value) => [`${value}%`, "النسبة"]}
                  contentStyle={{
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
                    fontWeight: "bold",
                    textAlign: "right",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            
            <div className="grid grid-cols-2 gap-y-4 gap-x-2 mt-4">
              {reportData.cities.map((city, index) => (
                <div key={city.id} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  ></div>
                  <span className="text-sm font-semibold text-slate-700">
                    {city.name}
                  </span>
                  <span className="text-sm text-slate-400 mr-auto">
                    {city.value}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tables Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Products - Full Width */}
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                أفضل المنتجات مبيعاً
              </h2>
              <p className="text-slate-500 text-sm font-medium">
                قائمة بالمنتجات الأكثر تحقيقاً للإيرادات
              </p>
            </div>
            <button className="text-sm font-bold text-amber-600 hover:text-amber-700 transition-colors">
              عرض الكل
            </button>
          </div>

          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 text-sm">
                  <th className="pb-3 font-medium whitespace-nowrap">المنتج</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الفئة</th>
                  <th className="pb-3 font-medium whitespace-nowrap">المبيعات</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الإيرادات</th>
                  <th className="pb-3 font-medium whitespace-nowrap">التوجه</th>
                </tr>
              </thead>
              <tbody>
                {reportData.products.map((product) => (
                  <tr
                    key={product.id}
                    className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors group"
                  >
                    <td className="py-4 font-bold text-slate-800 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500">
                        <ShoppingCart className="w-5 h-5" />
                      </div>
                      {product.name}
                    </td>
                    <td className="py-4 text-slate-500 text-sm font-medium">
                      {product.category}
                    </td>
                    <td className="py-4 font-semibold text-slate-700">
                      {product.sales.toLocaleString()}
                    </td>
                    <td className="py-4 font-bold text-slate-900">
                      {product.revenue.toLocaleString()} ر.س
                    </td>
                    <td className="py-4">
                      <div
                        className={cn(
                          "inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full",
                          product.isUp
                            ? "text-emerald-700 bg-emerald-50"
                            : "text-rose-700 bg-rose-50"
                        )}
                      >
                        {product.isUp ? (
                          <ArrowUpRight className="w-3 h-3" />
                        ) : (
                          <ArrowDownRight className="w-3 h-3" />
                        )}
                        {product.trend}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Customers */}
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                أفضل العملاء
              </h2>
              <p className="text-slate-500 text-sm font-medium">
                العملاء الأكثر ولاءً وتفاعلاً
              </p>
            </div>
            <button className="text-sm font-bold text-amber-600 hover:text-amber-700 transition-colors">
              عرض الكل
            </button>
          </div>
          <div className="overflow-x-auto custom-scrollbar flex-1">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 text-sm">
                  <th className="pb-3 font-medium whitespace-nowrap">العميل</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الطلبات</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الإنفاق</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الولاء</th>
                </tr>
              </thead>
              <tbody>
                {reportData.customers.map((customer) => (
                  <tr
                    key={customer.id}
                    className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors"
                  >
                    <td className="py-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center font-bold text-sm">
                        {customer.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-sm">{customer.name}</p>
                        <p className="text-xs text-slate-500">{customer.email}</p>
                      </div>
                    </td>
                    <td className="py-4 font-semibold text-slate-700">
                      {customer.orders}
                    </td>
                    <td className="py-4 font-bold text-slate-900">
                      {customer.revenue.toLocaleString()} ر.س
                    </td>
                    <td className="py-4">
                      <div className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-100 text-slate-700 text-xs font-bold">
                        <Award className="w-3.5 h-3.5 text-amber-500" />
                        {customer.loyaltyTier}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Cities */}
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                أداء المدن
              </h2>
              <p className="text-slate-500 text-sm font-medium">
                تفصيل أداء المبيعات حسب الموقع
              </p>
            </div>
            <button className="text-sm font-bold text-amber-600 hover:text-amber-700 transition-colors">
              عرض الكل
            </button>
          </div>
          <div className="overflow-x-auto custom-scrollbar flex-1">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 text-sm">
                  <th className="pb-3 font-medium whitespace-nowrap">المدينة</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الطلبات</th>
                  <th className="pb-3 font-medium whitespace-nowrap">الإيرادات</th>
                  <th className="pb-3 font-medium whitespace-nowrap">النمو</th>
                </tr>
              </thead>
              <tbody>
                {reportData.cities.map((city, index) => (
                  <tr
                    key={city.id}
                    className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors"
                  >
                    <td className="py-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-slate-800">{city.name}</span>
                    </td>
                    <td className="py-4 font-semibold text-slate-700">
                      {city.orders.toLocaleString()}
                    </td>
                    <td className="py-4 font-bold text-slate-900">
                      {city.revenue.toLocaleString()} ر.س
                    </td>
                    <td className="py-4">
                      <div
                        className={cn(
                          "inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-md",
                          city.isUp
                            ? "text-emerald-700 bg-emerald-50"
                            : "text-rose-700 bg-rose-50"
                        )}
                      >
                        {city.isUp ? (
                          <ArrowUpRight className="w-3 h-3" />
                        ) : (
                          <ArrowDownRight className="w-3 h-3" />
                        )}
                        {city.growth}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
