import * as z from "zod";

export const productSchema = z.object({
  name: z.string().min(1, "اسم المنتج مطلوب"),
  description: z.string().optional(),
  categoryId: z.string().min(1, "التصنيف مطلوب"),
  type: z.enum(["simple", "variable"]),
  price: z.string().min(1, "السعر مطلوب"),
  discountPrice: z.string().optional(),
  sku: z.string().optional(),
  barcode: z.string().optional(),
  trackInventory: z.boolean(),
  quantity: z.string().optional(),
  weight: z.string().optional(),
  seoTitle: z.string().optional(),
  seoDescription: z.string().optional(),
  variants: z
    .array(
      z.object({
        id: z.string(),
        name: z.string().optional(),
        attributes: z.array(
          z.object({
            name: z.string(),
            value: z.string(),
          })
        ).optional(),
        price: z.string().min(1, "السعر مطلوب"),
        discountPrice: z.string().optional(),
        sku: z.string().optional(),
        trackInventory: z.boolean().optional(),
        quantity: z.string().optional(),
      })
    )
    .optional(),
});

export type ProductFormValues = z.infer<typeof productSchema>;
