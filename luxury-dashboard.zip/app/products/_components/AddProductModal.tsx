"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { productSchema, ProductFormValues } from "../schema";
import { Category, Attribute } from "../types";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

import { PackageOpen, Sparkles, X } from "lucide-react";

import {
  BasicInfoTab,
  PricingTab,
  InventoryTab,
  ImagesTab,
  SEOTab,
} from "./AddProductTabs";
import { VariantsTab } from "./VariantsTab";

interface AddProductModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categories: Category[];
  attributes: Attribute[];
}

export default function AddProductModal({
  open,
  onOpenChange,
  categories,
  attributes,
}: AddProductModalProps) {
  const [activeTab, setActiveTab] = useState("basic");

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      description: "",
      categoryId: "",
      type: "simple",
      price: "",
      discountPrice: "",
      sku: "",
      barcode: "",
      trackInventory: true,
      quantity: "",
      weight: "",
      seoTitle: "",
      seoDescription: "",
      variants: [],
    },
  });

  const productType = form.watch("type");

  const onSubmit = (data: ProductFormValues) => {
    console.log("Submitted Product Data:", data);
    // TODO: Send data to backend here
    onOpenChange(false);
    form.reset();
    setActiveTab("basic");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden bg-slate-50 flex flex-col h-[90vh] md:h-[85vh] rounded-2xl md:rounded-3xl" dir="rtl">
        {/* Header */}
        <DialogHeader className="px-6 py-4 bg-white border-b border-slate-100 flex flex-row items-center justify-between shrink-0 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center shrink-0">
              <PackageOpen className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold text-slate-800 flex items-center gap-2">
                إضافة منتج جديد
                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-bold flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> مميز
                </span>
              </DialogTitle>
              <p className="text-sm text-slate-500 mt-1">أدخل تفاصيل المنتج ليتم عرضه في متجرك</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-slate-600 rounded-full" onClick={() => onOpenChange(false)}>
            <X className="w-5 h-5" />
          </Button>
        </DialogHeader>

        {/* Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full" dir="rtl">
            <TabsList className="w-full flex sm:flex-wrap gap-2 h-auto bg-transparent justify-start border-b border-slate-100 pb-4 mb-8 rounded-none overflow-x-auto custom-scrollbar no-scrollbar-on-mobile">
              <TabsTrigger value="basic" className="rounded-full px-5 py-2.5 data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:hover:bg-slate-100 data-[state=inactive]:text-slate-600 border border-slate-100 data-[state=active]:border-indigo-600 transition-all font-medium whitespace-nowrap">أساسي</TabsTrigger>
              <TabsTrigger value="pricing" className="rounded-full px-5 py-2.5 data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:hover:bg-slate-100 data-[state=inactive]:text-slate-600 border border-slate-100 data-[state=active]:border-indigo-600 transition-all font-medium whitespace-nowrap">التسعير</TabsTrigger>
              <TabsTrigger value="inventory" className="rounded-full px-5 py-2.5 data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:hover:bg-slate-100 data-[state=inactive]:text-slate-600 border border-slate-100 data-[state=active]:border-indigo-600 transition-all font-medium whitespace-nowrap">المخزون</TabsTrigger>
              {productType === "variable" && (
                <TabsTrigger value="variants" className="rounded-full px-5 py-2.5 data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:hover:bg-slate-100 data-[state=inactive]:text-slate-600 border border-slate-100 data-[state=active]:border-indigo-600 transition-all font-medium whitespace-nowrap">المتغيرات</TabsTrigger>
              )}
              <TabsTrigger value="images" className="rounded-full px-5 py-2.5 data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:hover:bg-slate-100 data-[state=inactive]:text-slate-600 border border-slate-100 data-[state=active]:border-indigo-600 transition-all font-medium whitespace-nowrap">الصور</TabsTrigger>
              <TabsTrigger value="seo" className="rounded-full px-5 py-2.5 data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white data-[state=inactive]:hover:bg-slate-100 data-[state=inactive]:text-slate-600 border border-slate-100 data-[state=active]:border-indigo-600 transition-all font-medium whitespace-nowrap">SEO</TabsTrigger>
            </TabsList>

            <form id="product-form" onSubmit={form.handleSubmit(onSubmit)}>
              <div className="max-w-4xl mx-auto">
                <TabsContent value="basic" className="space-y-6 mt-0">
                  <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm">
                    <BasicInfoTab form={form} categories={categories} />
                  </div>
                </TabsContent>

                <TabsContent value="pricing" className="mt-0 h-full">
                  <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm">
                    <PricingTab form={form} />
                  </div>
                </TabsContent>

                <TabsContent value="inventory" className="mt-0 h-full">
                  <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm">
                    <InventoryTab form={form} />
                  </div>
                </TabsContent>

                {productType === "variable" && (
                  <TabsContent value="variants" className="mt-0">
                    <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm">
                      <VariantsTab form={form} attributes={attributes} />
                    </div>
                  </TabsContent>
                )}

                <TabsContent value="images" className="mt-0">
                  <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm">
                    <ImagesTab />
                  </div>
                </TabsContent>

                <TabsContent value="seo" className="mt-0">
                  <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm">
                    <SEOTab form={form} />
                  </div>
                </TabsContent>
              </div>
            </form>
          </Tabs>
        </div>

        {/* Footer */}
        <DialogFooter className="px-6 py-4 bg-white border-t border-slate-100 shrink-0 flex items-center justify-between gap-4 sticky bottom-0 z-10 flex-col sm:flex-row">
          <Button type="button" variant="outline" className="w-full sm:w-auto font-bold border-slate-200 text-slate-600 hover:bg-slate-50" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button type="submit" form="product-form" className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-8 shadow-md hover:shadow-lg transition-all">
            حفظ المنتج
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
