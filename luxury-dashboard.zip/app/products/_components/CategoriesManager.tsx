"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, FolderTree, Trash2, Edit2, Check, X } from "lucide-react";
import { Category } from "../types";

interface CategoriesManagerProps {
  categories: Category[];
  onAddCategory: (name: string, parentId: string | null) => void;
  onDeleteCategory: (id: string) => void;
}

export default function CategoriesManager({
  categories,
  onAddCategory,
  onDeleteCategory,
}: CategoriesManagerProps) {
  const [newCatName, setNewCatName] = useState("");
  const [selectedParentId, setSelectedParentId] = useState<string>("none");
  const [categoryToDelete, setCategoryToDelete] = useState<string | null>(null);

  const handleAdd = () => {
    if (newCatName.trim()) {
      onAddCategory(
        newCatName.trim(),
        selectedParentId === "none" ? null : selectedParentId,
      );
      setNewCatName("");
      setSelectedParentId("none");
    }
  };

  const confirmDelete = () => {
    if (categoryToDelete) {
      onDeleteCategory(categoryToDelete);
      setCategoryToDelete(null);
    }
  };

  // Helper to get children
  const getChildren = (parentId: string | null) =>
    categories.filter((c) => c.parentId === parentId);

  const renderCategoryTree = (parentId: string | null = null, depth = 0) => {
    const children = getChildren(parentId);
    if (children.length === 0) return null;

    return (
      <ul className="space-y-2">
        {children.map((category) => (
          <li key={category.id} className="relative">
            <div
              className={`flex items-center justify-between p-3 bg-white border border-slate-100 rounded-xl shadow-sm hover:shadow-md transition-shadow group ${depth > 0 ? "mt-2" : ""}`}
              style={{ marginRight: depth > 0 ? `${depth * 1.5}rem` : "0" }}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                  <FolderTree className="w-4 h-4" />
                </div>
                <span className="font-medium text-slate-800">
                  {category.name}
                </span>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={() => setCategoryToDelete(category.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            {renderCategoryTree(category.id, depth + 1)}
          </li>
        ))}
      </ul>
    );
  };

  return (
    <div className="space-y-8">
      {/* Add New Category */}
      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <FolderTree className="w-5 h-5 text-indigo-500" />
          إضافة تصنيف جديد
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="space-y-2">
            <Label>اسم التصنيف</Label>
            <Input
              placeholder="مثال: إلكترونيات، ملابس رجالية..."
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAdd()}
            />
          </div>
          <div className="space-y-2">
            <Label>يتبع لتصنيف (الأب)</Label>
            <Select
              dir="rtl"
              value={selectedParentId}
              onValueChange={setSelectedParentId}
            >
              <SelectTrigger>
                <SelectValue placeholder="التصنيف الأساسي" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">-- تصنيف رئيسي --</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button
            onClick={handleAdd}
            disabled={!newCatName.trim()}
            className="bg-indigo-600 hover:bg-indigo-700 gap-2 h-10 w-full"
          >
            <Plus className="w-4 h-4" />
            إضافة
          </Button>
        </div>
      </div>

      {/* Category Tree */}
      <div className="bg-slate-50/50 p-6 rounded-3xl border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-6">
          هيكلة التصنيفات
        </h3>
        {categories.length === 0 ? (
          <div className="text-center py-10 text-slate-500 font-medium">
            لا توجد تصنيفات حالياً. أضف تصنيفاً جديداً لتبدأ.
          </div>
        ) : (
          renderCategoryTree(null, 0)
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={!!categoryToDelete}
        onOpenChange={(open) => !open && setCategoryToDelete(null)}
      >
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-red-600 text-right flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              تأكيد الحذف
            </DialogTitle>
          </DialogHeader>
          <div className="py-4 text-right">
            <p className="text-slate-600 font-medium">
              هل أنت متأكد من حذف هذا التصنيف؟
              <br />
              <span className="text-red-500 font-bold mt-2 inline-block">
                تحذير: سيتم حذف جميع التصنيفات الفرعية المرتبطة به بشكل نهائي!
              </span>
            </p>
          </div>
          <DialogFooter className="gap-2 sm:gap-0 flex-row justify-end">
            <Button
              variant="outline"
              onClick={() => setCategoryToDelete(null)}
            >
              إلغاء
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              نعم، قم بالحذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
