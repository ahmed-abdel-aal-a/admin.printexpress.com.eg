"use client";
import { UseFormReturn, useFieldArray } from "react-hook-form";
import { ProductFormValues } from "../schema";
import { Category, Attribute } from "../types";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Trash2, ImageIcon, Coins, Tag, ChevronDown, PackageOpen, Sparkles } from "lucide-react";
import { useState } from "react";

// --- BasicInfoTab ---
export function BasicInfoTab({ form, categories }: { form: UseFormReturn<ProductFormValues>; categories: Category[] }) {
  const { register, formState: { errors } } = form;
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>اسم المنتج <span className="text-red-500">*</span></Label>
        <Input placeholder="أدخل اسم المنتج" {...register("name")} className={errors.name ? "border-red-500" : ""} />
        {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}
      </div>
      <div className="space-y-2">
        <Label>وصف المنتج</Label>
        <Textarea placeholder="اكتب وصفاً تفصيلياً للمنتج..." className="h-32" {...register("description")} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>التصنيف <span className="text-red-500">*</span></Label>
          <Select dir="rtl" onValueChange={(val) => form.setValue("categoryId", val)} value={form.watch("categoryId") || ""}>
            <SelectTrigger className={errors.categoryId ? "border-red-500" : ""}>
              <SelectValue placeholder="اختر التصنيف" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.categoryId && <p className="text-red-500 text-xs mt-1">{errors.categoryId.message}</p>}
        </div>
        <div className="space-y-2">
          <Label>نوع المنتج</Label>
          <Select dir="rtl" onValueChange={(val: "simple" | "variable") => form.setValue("type", val)} value={form.watch("type") || "simple"}>
            <SelectTrigger>
              <SelectValue placeholder="اختر نوع المنتج" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="simple">بسيط</SelectItem>
              <SelectItem value="variable">متغير (له مقاسات/ألوان)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}

// --- PricingTab ---
export function PricingTab({ form }: { form: UseFormReturn<ProductFormValues> }) {
  const { register, formState: { errors } } = form;
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>السعر الأساسي <span className="text-red-500">*</span></Label>
          <div className="relative">
            <Input type="number" placeholder="0.00" {...register("price")} className={`pl-12 ${errors.price ? "border-red-500" : ""}`} />
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">ج.م</span>
          </div>
          {errors.price && <p className="text-red-500 text-xs mt-1">{errors.price.message}</p>}
        </div>
        <div className="space-y-2">
          <Label>السعر بعد التخفيض</Label>
          <div className="relative">
            <Input type="number" placeholder="0.00" {...register("discountPrice")} className="pl-12" />
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">ج.م</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- InventoryTab ---
export function InventoryTab({ form }: { form: UseFormReturn<ProductFormValues> }) {
  const { register } = form;
  const trackInventory = form.watch("trackInventory");
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>SKU (رمز التخزين)</Label>
          <Input placeholder="مثال: PRD-001" {...register("sku")} />
        </div>
        <div className="space-y-2">
          <Label>الباركود (Barcode)</Label>
          <Input placeholder="أدخل رقم الباركود" {...register("barcode")} />
        </div>
      </div>
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-between">
        <div>
          <h4 className="font-bold text-slate-800">تتبع المخزون</h4>
          <p className="text-sm text-slate-500">قم بتفعيل هذا الخيار لتتبع كميات هذا المنتج</p>
        </div>
        <input type="checkbox" className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" checked={trackInventory} onChange={(e) => form.setValue("trackInventory", e.target.checked)} />
      </div>
      {trackInventory && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="space-y-2">
            <Label>الكمية المتاحة</Label>
            <Input type="number" placeholder="0" {...register("quantity")} />
          </div>
          <div className="space-y-2">
            <Label>الوزن (كجم)</Label>
            <Input type="number" placeholder="0.0" {...register("weight")} />
          </div>
        </div>
      )}
    </div>
  );
}

// --- ImagesTab ---
export function ImagesTab() {
  return (
    <div className="space-y-6">
      <div className="border-2 border-dashed border-slate-200 rounded-3xl p-12 flex flex-col items-center justify-center text-center bg-slate-50/50 hover:bg-slate-50 transition-colors cursor-pointer">
        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
          <ImageIcon className="w-8 h-8 text-indigo-500" />
        </div>
        <h4 className="text-lg font-bold text-slate-800 mb-1">أضف صور المنتج</h4>
        <p className="text-slate-500 text-sm max-w-sm mb-6">اسحب وأفلت الصور هنا، أو اضغط لاختيار ملفات من جهازك. يُفضل استخدام صور بخلفية بيضاء وبدقة عالية.</p>
        <Button variant="outline" className="bg-white">استعراض الملفات</Button>
      </div>
    </div>
  );
}

// --- SEOTab ---
export function SEOTab({ form }: { form: UseFormReturn<ProductFormValues> }) {
  const { register } = form;
  return (
    <div className="space-y-6">
      <div className="bg-blue-50 text-blue-800 p-4 rounded-xl text-sm font-medium flex items-start gap-3">
        <Sparkles className="w-5 h-5 mt-0.5 shrink-0" />
        <p>هذه المعلومات تساعد في ظهور منتجك بشكل أفضل في محركات البحث مثل جوجل.</p>
      </div>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>عنوان صفحة المنتج (SEO Title)</Label>
          <Input placeholder="عنوان يظهر في محركات البحث" {...register("seoTitle")} />
        </div>
        <div className="space-y-2">
          <Label>وصف صفحة المنتج (SEO Description)</Label>
          <Textarea placeholder="وصف موجز للمنتج يظهر أسفل العنوان في محركات البحث..." className="h-24" {...register("seoDescription")} />
        </div>
      </div>
    </div>
  );
}
