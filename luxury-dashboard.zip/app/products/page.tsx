"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import { Button } from "@/components/ui/button";

import { Plus } from "lucide-react";

import AddProductModal from "./_components/AddProductModal";

import CategoriesManager from "./_components/CategoriesManager";

import AttributesManager from "./_components/AttributesManager";

import { useState } from "react";

import { Category, Attribute } from "./types";

// Default Color attribute with all basic colors
const DEFAULT_COLOR_ATTRIBUTE: Attribute = {
  id: "attr-color",
  name: "اللون",
  values: [
    "أحمر",
    "أزرق",
    "أخضر",
    "أصفر",
    "أسود",
    "أبيض",
    "رمادي",
    "وردي",
    "برتقالي",
    "بنفسجي",
  ],
};

export default function ProductsPage() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const [categories, setCategories] = useState<Category[]>([
    { id: "cat-1", name: "ملابس", parentId: null },
    { id: "cat-2", name: "رجالي", parentId: "cat-1" },
    { id: "cat-3", name: "إلكترونيات", parentId: null },
  ]);

  const [attributes, setAttributes] = useState<Attribute[]>([
    DEFAULT_COLOR_ATTRIBUTE,
  ]);

  // Category Handlers
  const handleAddCategory = (name: string, parentId: string | null) => {
    setCategories((prev) => [
      ...prev,
      { id: `cat-${Date.now()}`, name, parentId },
    ]);
  };

  const handleDeleteCategory = (id: string) => {
    setCategories((prev) => {
      // Also delete children recursively or just remove them (simplifying here)
      const toDelete = new Set([id]);

      let added = true;

      while (added) {
        added = false;

        prev.forEach((c) => {
          if (c.parentId && toDelete.has(c.parentId) && !toDelete.has(c.id)) {
            toDelete.add(c.id);

            added = true;
          }
        });
      }
      return prev.filter((c) => !toDelete.has(c.id));
    });
  };

  // Attribute Handlers
  const handleAddAttribute = (name: string, initialValues: string[]) => {
    setAttributes((prev) => [
      ...prev,
      { id: `attr-${Date.now()}`, name, values: initialValues },
    ]);
  };

  const handleDeleteAttribute = (id: string) => {
    setAttributes((prev) =>
      prev.filter((a) => a.id !== id || a.name === "اللون"),
    );
    // Protect Color
  };

  const handleAddValueToAttribute = (attrId: string, value: string) => {
    setAttributes((prev) =>
      prev.map((a) =>
        a.id === attrId
          ? {
              ...a,
              values: a.values.includes(value)
                ? a.values
                : [...a.values, value],
            }
          : a,
      ),
    );
  };

  const handleRemoveValueFromAttribute = (attrId: string, value: string) => {
    setAttributes((prev) =>
      prev.map((a) =>
        a.id === attrId
          ? { ...a, values: a.values.filter((v) => v !== value) }
          : a,
      ),
    );
  };

  return (
    <div className="space-y-8" dir="rtl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
            إدارة المنتجات
          </h1>
          <p className="text-slate-500 mt-1 text-sm">
            أضف، عدل، وأدر منتجات متجرك.
          </p>
        </div>
        <Button onClick={() => setIsAddModalOpen(true)} className="gap-2">
          <Plus className="w-5 h-5" />
          إضافة منتج
        </Button>
      </div>

      <Tabs defaultValue="products" className="w-full" dir="rtl">
        <TabsList className="mb-6 h-auto p-1 bg-white shadow-sm border border-slate-100 rounded-2xl w-full sm:w-auto overflow-x-auto justify-start">
          <TabsTrigger
            value="products"
            className="px-6 py-2.5 rounded-xl font-bold"
          >
            المنتجات
          </TabsTrigger>
          <TabsTrigger
            value="categories"
            className="px-6 py-2.5 rounded-xl font-bold"
          >
            التصنيفات
          </TabsTrigger>
          <TabsTrigger
            value="attributes"
            className="px-6 py-2.5 rounded-xl font-bold"
          >
            المتغيرات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="mt-0">
          <div className="bg-white rounded-3xl p-8 text-center border border-white shadow-sm">
            <div className="w-24 h-24 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-4xl">📦</span>
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">
              لا توجد منتجات حتى الآن
            </h3>
            <p className="text-slate-500 max-w-sm mx-auto mb-6 font-medium">
              ابدأ بإضافة منتجك الأول لتبدأ في البيع وعرض منتجاتك للعملاء.
            </p>
            <Button
              onClick={() => setIsAddModalOpen(true)}
              variant="outline"
              className="gap-2 font-bold"
            >
              <Plus className="w-4 h-4" />
              أضف منتجك الأول
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="categories" className="mt-0">
          <CategoriesManager
            categories={categories}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
          />
        </TabsContent>

        <TabsContent value="attributes" className="mt-0">
          <AttributesManager
            attributes={attributes}
            onAddAttribute={handleAddAttribute}
            onDeleteAttribute={handleDeleteAttribute}
            onAddValueToAttribute={handleAddValueToAttribute}
            onRemoveValueFromAttribute={handleRemoveValueFromAttribute}
          />
        </TabsContent>
      </Tabs>

      <AddProductModal
        open={isAddModalOpen}
        onOpenChange={setIsAddModalOpen}
        categories={categories}
        attributes={attributes}
      />
    </div>
  );
}
