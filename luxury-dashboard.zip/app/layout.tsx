import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import ClientShell from "@/components/ClientShell";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
});

export const metadata: Metadata = {
  title: "لوحة التحكم الفاخرة",
  description: "إدارة المنتجات والمبيعات باحترافية",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <body
        className="font-cairo bg-[#F4F7FE] text-slate-800 flex h-screen overflow-hidden antialiased selection:bg-amber-100 selection:text-amber-900"
        suppressHydrationWarning
      >
        <ClientShell>
          {children}
        </ClientShell>
      </body>
    </html>
  );
}
