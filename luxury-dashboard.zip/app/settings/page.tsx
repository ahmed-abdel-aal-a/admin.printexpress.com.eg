"use client";

import React, { useState } from "react";
import {
  Settings,
  Truck,
  CreditCard,
  Bell,
  User,
  Shield,
  Save,
  MapPin,
  Building,
  CheckCircle2,
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  Package,
  X,
  KeyRound
} from "lucide-react";
import { cn } from "@/lib/utils";

// --- Types ---
type TabId = "shipping" | "general" | "payment" | "notifications" | "security";

interface ShippingCompany {
  id: string;
  name: string;
  logoUrl?: string;
  description: string;
  isActive: boolean;
  isConfigured: boolean;
  codSupported: boolean;
}

interface PaymentGateway {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  isConfigured: boolean;
  type: string;
}

interface GovernorateRate {
  id: string;
  name: string;
  rate: number | string;
  deliveryDays: string;
}

// --- Mock Data ---
const shippingCompanies: ShippingCompany[] = [
  { id: "bosta", name: "بوسطة (Bosta)", description: "توصيل سريع وموثوق في جميع أنحاء مصر مع دعم الدفع عند الاستلام.", isActive: true, isConfigured: true, codSupported: true },
  { id: "aramex", name: "أرامكس (Aramex)", description: "تغطية شاملة داخل مصر وخدمات شحن دولية.", isActive: false, isConfigured: true, codSupported: true },
  { id: "mylerz", name: "مايلرز (Mylerz)", description: "توصيل في نفس اليوم لبعض المناطق وخدمة عملاء ممتازة.", isActive: true, isConfigured: false, codSupported: true },
  { id: "sprint", name: "سبرينت (Sprint)", description: "حلول لوجستية متكاملة للتجارة الإلكترونية.", isActive: false, isConfigured: false, codSupported: true },
  { id: "r2s", name: "R2S Logistics", description: "شحن وتوصيل وإدارة مرتجعات بكفاءة عالية.", isActive: false, isConfigured: false, codSupported: true },
];

const paymentGatewaysList: PaymentGateway[] = [
  { id: "kashier", name: "كاشير (Kashier)", description: "بوابة دفع مصرية متكاملة تدعم البطاقات البنكية والمحافظ الإلكترونية.", isActive: true, isConfigured: false, type: "cards,wallets" },
  { id: "paymob", name: "باي موب (Paymob)", description: "حلول دفع شاملة تدعم أكثر من طريقة دفع محلياً.", isActive: false, isConfigured: false, type: "cards,wallets,kiosk" },
  { id: "fawry", name: "فوري (Fawry)", description: "شبكة الدفع الإلكتروني الأكبر لدفع نقدي وعبر البطاقات.", isActive: false, isConfigured: false, type: "cash,cards" },
];

const governorateRates: GovernorateRate[] = [
  { id: "cairo", name: "القاهرة والجيزة", rate: 45, deliveryDays: "1-2" },
  { id: "alex", name: "الإسكندرية", rate: 55, deliveryDays: "2-3" },
  { id: "delta", name: "محافظات الدلتا", rate: 65, deliveryDays: "2-4" },
  { id: "canal", name: "مدن القناة", rate: 65, deliveryDays: "2-4" },
  { id: "upper", name: "الصعيد", rate: 80, deliveryDays: "3-5" },
  { id: "redsea_sinai", name: "البحر الأحمر وسيناء", rate: 95, deliveryDays: "4-7" },
];

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<TabId>("shipping");
  
  // Shipping State
  const [companies, setCompanies] = useState<ShippingCompany[]>(shippingCompanies);
  const [rates, setRates] = useState<GovernorateRate[]>(governorateRates);
  const [codEnabled, setCodEnabled] = useState(true);
  const [codFee, setCodFee] = useState<number | string>(15);
  const [freeShippingEnabled, setFreeShippingEnabled] = useState(true);
  const [freeShippingThreshold, setFreeShippingThreshold] = useState<number | string>(1000);

  // Payment State
  const [paymentGateways, setPaymentGateways] = useState<PaymentGateway[]>(paymentGatewaysList);

  // Modal State
  const [configModalOpen, setConfigModalOpen] = useState(false);
  const [configType, setConfigType] = useState<"shipping" | "payment">("shipping");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});
  const [warehouseGovernorate, setWarehouseGovernorate] = useState("القاهرة");
  const [warehouseCity, setWarehouseCity] = useState("مدينة نصر");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleCompanyStatus = (id: string) => {
    setCompanies(companies.map(c => c.id === id ? { ...c, isActive: !c.isActive } : c));
  };

  const togglePaymentGatewayStatus = (id: string) => {
    setPaymentGateways(paymentGateways.map(p => p.id === id ? { ...p, isActive: !p.isActive } : p));
  };

  const handleRateChange = (id: string, newRate: string) => {
    const value = newRate === "" ? "" : Number(newRate);
    setRates(rates.map(r => r.id === id ? { ...r, rate: value } : r));
  };

  const openConfigModal = (id: string, type: "shipping" | "payment") => {
    setSelectedId(id);
    setConfigType(type);
    setConfigModalOpen(true);
  };

  const closeConfigModal = () => {
    setConfigModalOpen(false);
    setSelectedId(null);
  };

  const saveConfig = () => {
    if (selectedId) {
      if (configType === "shipping") {
        setCompanies(companies.map(c => 
          c.id === selectedId ? { ...c, isConfigured: true } : c
        ));
      } else {
        setPaymentGateways(paymentGateways.map(p => 
          p.id === selectedId ? { ...p, isConfigured: true } : p
        ));
      }
    }
    closeConfigModal();
  };

  const selectedCompany = companies.find(c => c.id === selectedId);
  const selectedPaymentGateway = paymentGateways.find(p => p.id === selectedId);

  return (
    <div className="min-h-screen bg-[#FDFDFD] p-6 lg:p-8 font-sans" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight mb-1">
            الإعدادات
          </h1>
          <p className="text-slate-500 font-medium text-sm">
            إدارة إعدادات المتجر والشحن والمدفوعات
          </p>
        </div>
        <button className="bg-slate-900 hover:bg-slate-800 text-white py-2.5 px-6 rounded-xl shadow-lg shadow-slate-900/20 transition-all flex items-center justify-center gap-2 font-bold text-sm">
          <Save className="w-4 h-4" />
          <span>حفظ التغييرات</span>
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar Navigation */}
        <div className="w-full lg:w-64 flex-shrink-0">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-3 sticky top-6">
            <nav className="flex flex-col gap-1">
              {([
                { id: "shipping", label: "إعدادات الشحن", icon: Truck },
                { id: "general", label: "عام", icon: Settings },
                { id: "payment", label: "الدفع", icon: CreditCard },
                { id: "notifications", label: "الإشعارات", icon: Bell },
                { id: "security", label: "الأمان والصلاحيات", icon: Shield },
              ] as const).map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabId)}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-semibold text-sm w-full text-right",
                    activeTab === tab.id
                      ? "bg-amber-50 text-amber-700"
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  )}
                >
                  <tab.icon className="w-5 h-5" />
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1">
          {activeTab === "shipping" && (
            <div className="space-y-6">
              
              {/* Shipping Companies (Egypt) */}
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex items-center gap-3">
                  <div className="p-2 bg-amber-100 text-amber-700 rounded-lg">
                    <Truck className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">شركات الشحن (مصر)</h2>
                    <p className="text-sm text-slate-500 font-medium">قم بتفعيل وربط شركات الشحن المحلية</p>
                  </div>
                </div>
                
                <div className="p-0">
                  {companies.map((company, index) => (
                    <div key={company.id} className={cn(
                      "p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors",
                      index !== companies.length - 1 ? "border-b border-slate-100" : "",
                      company.isActive ? "bg-white" : "bg-slate-50/50"
                    )}>
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 shadow-sm flex items-center justify-center flex-shrink-0 text-slate-400 font-bold text-sm">
                          {company.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold text-slate-900">{company.name}</h3>
                            {company.isActive && company.isConfigured && (
                              <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                                <CheckCircle2 className="w-3 h-3" />
                                متصل
                              </span>
                            )}
                            {company.isActive && !company.isConfigured && (
                              <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                                <AlertCircle className="w-3 h-3" />
                                يحتاج إعداد
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-slate-500 max-w-md">{company.description}</p>
                          {company.codSupported && (
                            <div className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-slate-600 bg-slate-100 w-fit px-2 py-1 rounded-md">
                              <CreditCard className="w-3.5 h-3.5" />
                              يدعم الدفع عند الاستلام
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
                        <button 
                          onClick={() => openConfigModal(company.id, "shipping")}
                          className="flex-1 sm:flex-none px-4 py-2 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors"
                        >
                          الإعدادات
                        </button>
                        <button 
                          onClick={() => toggleCompanyStatus(company.id)}
                          className="flex items-center gap-2"
                        >
                          {company.isActive ? (
                            <ToggleRight className="w-10 h-10 text-amber-500" />
                          ) : (
                            <ToggleLeft className="w-10 h-10 text-slate-300 hover:text-slate-400 transition-colors" />
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery Rates by Region */}
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex items-center gap-3">
                  <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">تسعير الشحن حسب المنطقة</h2>
                    <p className="text-sm text-slate-500 font-medium">حدد تكلفة الشحن لكل منطقة في مصر</p>
                  </div>
                </div>
                
                <div className="p-6 overflow-x-auto custom-scrollbar">
                  <table className="w-full text-right border-collapse min-w-[500px]">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 text-sm">
                        <th className="pb-3 font-semibold">المنطقة / المحافظة</th>
                        <th className="pb-3 font-semibold w-32">مدة التوصيل (أيام)</th>
                        <th className="pb-3 font-semibold w-40">تكلفة الشحن (جنيه)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rates.map((rate) => (
                        <tr key={rate.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors">
                          <td className="py-4 font-bold text-slate-800">{rate.name}</td>
                          <td className="py-4 text-slate-600 font-medium text-sm" dir="ltr">
                            <div className="bg-slate-100 px-3 py-1.5 rounded-lg inline-block text-center w-full">
                              {rate.deliveryDays}
                            </div>
                          </td>
                          <td className="py-4">
                            <div className="relative">
                              <input 
                                type="number" 
                                value={rate.rate}
                                onChange={(e) => handleRateChange(rate.id, e.target.value)}
                                className="w-full bg-white border border-slate-200 rounded-lg py-1.5 px-3 text-slate-900 font-bold focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all pr-12"
                              />
                              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">ج.م</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* COD & Free Shipping Settings */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Cash on Delivery */}
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                        <CreditCard className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">الدفع عند الاستلام</h2>
                        <p className="text-sm text-slate-500 font-medium mt-0.5">رسوم إضافية لخدمة الـ COD</p>
                      </div>
                    </div>
                    <button onClick={() => setCodEnabled(!codEnabled)}>
                      {codEnabled ? (
                        <ToggleRight className="w-10 h-10 text-amber-500" />
                      ) : (
                        <ToggleLeft className="w-10 h-10 text-slate-300" />
                      )}
                    </button>
                  </div>
                  
                  <div className={cn("mt-auto transition-opacity", codEnabled ? "opacity-100" : "opacity-50 pointer-events-none")}>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      رسوم الخدمة (تضاف للعميل)
                    </label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={codFee}
                        onChange={(e) => setCodFee(e.target.value === "" ? "" : Number(e.target.value))}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 font-bold focus:bg-white focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all pr-12"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">ج.م</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      سيتم إضافة هذا المبلغ تلقائياً لإجمالي الطلب عند اختيار العميل للدفع عند الاستلام.
                    </p>
                  </div>
                </div>

                {/* Free Shipping */}
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
                        <Package className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">الشحن المجاني</h2>
                        <p className="text-sm text-slate-500 font-medium mt-0.5">تحفيز العملاء بحد أدنى للطلب</p>
                      </div>
                    </div>
                    <button onClick={() => setFreeShippingEnabled(!freeShippingEnabled)}>
                      {freeShippingEnabled ? (
                        <ToggleRight className="w-10 h-10 text-amber-500" />
                      ) : (
                        <ToggleLeft className="w-10 h-10 text-slate-300" />
                      )}
                    </button>
                  </div>
                  
                  <div className={cn("mt-auto transition-opacity", freeShippingEnabled ? "opacity-100" : "opacity-50 pointer-events-none")}>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      الحد الأدنى للطلب للشحن المجاني
                    </label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={freeShippingThreshold}
                        onChange={(e) => setFreeShippingThreshold(e.target.value === "" ? "" : Number(e.target.value))}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 font-bold focus:bg-white focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all pr-12"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">ج.م</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      الطلبات التي تتجاوز هذا المبلغ ستحصل على شحن مجاني (يطبق على بعض المحافظات).
                    </p>
                  </div>
                </div>
              </div>

              {/* Origin Address */}
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-slate-100 text-slate-700 rounded-lg">
                    <Building className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">عنوان المستودع / المتجر الرئيسي</h2>
                    <p className="text-sm text-slate-500 font-medium">سيستخدم هذا العنوان لحساب تكاليف الشحن وتوجيه المندوبين</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">المحافظة</label>
                    <select 
                      value={warehouseGovernorate}
                      onChange={(e) => setWarehouseGovernorate(e.target.value)}
                      className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 font-bold focus:bg-white focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all cursor-pointer"
                    >
                      <option value="القاهرة">القاهرة</option>
                      <option value="الجيزة">الجيزة</option>
                      <option value="الإسكندرية">الإسكندرية</option>
                      <option value="القليوبية">القليوبية</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">المدينة / المنطقة</label>
                    <select 
                      value={warehouseCity}
                      onChange={(e) => setWarehouseCity(e.target.value)}
                      className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 font-bold focus:bg-white focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all cursor-pointer"
                    >
                      <option value="مدينة نصر">مدينة نصر</option>
                      <option value="المعادي">المعادي</option>
                      <option value="مصر الجديدة">مصر الجديدة</option>
                      <option value="التجمع الخامس">التجمع الخامس</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold text-slate-700 mb-2">العنوان بالتفصيل</label>
                    <input 
                      type="text" 
                      defaultValue="شارع عباس العقاد، متفرع من مصطفى النحاس، مبنى رقم 15، الدور الثاني"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 font-medium focus:bg-white focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                </div>
              </div>

            </div>
          )}

          {activeTab === "payment" && (
            <div className="space-y-6">
              {/* Payment Gateways */}
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex items-center gap-3">
                  <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">بوابات الدفع الإلكتروني</h2>
                    <p className="text-sm text-slate-500 font-medium">قم بربط بوابات الدفع لاستقبال المدفوعات من عملائك بأمان</p>
                  </div>
                </div>
                
                <div className="p-0">
                  {paymentGateways.map((gateway, index) => (
                    <div key={gateway.id} className={cn(
                      "p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors",
                      index !== paymentGateways.length - 1 ? "border-b border-slate-100" : "",
                      gateway.isActive ? "bg-white" : "bg-slate-50/50"
                    )}>
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 shadow-sm flex items-center justify-center flex-shrink-0 text-slate-400 font-bold text-sm">
                          {gateway.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold text-slate-900">{gateway.name}</h3>
                            {gateway.isActive && gateway.isConfigured && (
                              <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                                <CheckCircle2 className="w-3 h-3" />
                                متصل
                              </span>
                            )}
                            {gateway.isActive && !gateway.isConfigured && (
                              <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                                <AlertCircle className="w-3 h-3" />
                                يحتاج إعداد
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-slate-500 max-w-md">{gateway.description}</p>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {gateway.type.includes("cards") && (
                              <span className="flex items-center gap-1 text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-1 rounded-md">
                                <CreditCard className="w-3 h-3" /> البطاقات البنكية
                              </span>
                            )}
                            {gateway.type.includes("wallets") && (
                              <span className="flex items-center gap-1 text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-1 rounded-md">
                                <Shield className="w-3 h-3" /> المحافظ الإلكترونية
                              </span>
                            )}
                            {gateway.type.includes("kiosk") && (
                              <span className="flex items-center gap-1 text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-1 rounded-md">
                                <Package className="w-3 h-3" /> نقاط البيع
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
                        <button 
                          onClick={() => openConfigModal(gateway.id, "payment")}
                          className="flex-1 sm:flex-none px-4 py-2 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors"
                        >
                          الإعدادات
                        </button>
                        <button 
                          onClick={() => togglePaymentGatewayStatus(gateway.id)}
                          className="flex items-center gap-2"
                        >
                          {gateway.isActive ? (
                            <ToggleRight className="w-10 h-10 text-amber-500" />
                          ) : (
                            <ToggleLeft className="w-10 h-10 text-slate-300 hover:text-slate-400 transition-colors" />
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab !== "shipping" && activeTab !== "payment" && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-12 flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4 border border-slate-100">
                <Settings className="w-8 h-8 text-slate-400" />
              </div>
              <h2 className="text-xl font-bold text-slate-800 mb-2">جاري العمل على هذا القسم</h2>
              <p className="text-slate-500 max-w-sm mx-auto">
                هذا القسم سيتم ربطه قريباً بلوحة التحكم الرئيسية للمتجر والواجهة الخلفية.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Configuration Modal */}
      {configModalOpen && (selectedCompany || selectedPaymentGateway) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-6 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-700 font-bold">
                  {configType === "shipping" ? selectedCompany?.name.charAt(0) : selectedPaymentGateway?.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">إعدادات {configType === "shipping" ? selectedCompany?.name : selectedPaymentGateway?.name}</h3>
                  <p className="text-xs text-slate-500 font-medium">الربط مع واجهة برمجة التطبيقات (API)</p>
                </div>
              </div>
              <button 
                onClick={closeConfigModal}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-5">
              <div className="bg-blue-50 text-blue-800 p-4 rounded-xl flex gap-3 text-sm font-medium">
                <KeyRound className="w-5 h-5 text-blue-600 shrink-0" />
                <p>قم بإدخال بيانات الربط (API Keys) الخاصة بحسابك في {configType === "shipping" ? selectedCompany?.name : selectedPaymentGateway?.name} لتفعيل التكامل والربط المباشر.</p>
              </div>

              {/* Shipping Specific Fields */}
              {configType === "shipping" && selectedCompany && selectedCompany.id === "bosta" && (
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">مفتاح الربط (API Key)</label>
                  <input 
                    type="password"
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI..."
                    value={apiKeys[`${selectedCompany.id}_apiKey`] || ""}
                    onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_apiKey`]: e.target.value})}
                    className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                  />
                </div>
              )}

              {configType === "shipping" && selectedCompany && selectedCompany.id === "aramex" && (
                <>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">اسم المستخدم (Username)</label>
                    <input 
                      type="text"
                      value={apiKeys[`${selectedCompany.id}_username`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_username`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">كلمة المرور (Password)</label>
                    <input 
                      type="password"
                      value={apiKeys[`${selectedCompany.id}_password`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_password`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">رقم الحساب</label>
                      <input 
                        type="text"
                        value={apiKeys[`${selectedCompany.id}_accountNumber`] || ""}
                        onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_accountNumber`]: e.target.value})}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">رقم الـ PIN</label>
                      <input 
                        type="password"
                        value={apiKeys[`${selectedCompany.id}_accountPin`] || ""}
                        onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_accountPin`]: e.target.value})}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                      />
                    </div>
                  </div>
                </>
              )}

              {configType === "shipping" && selectedCompany && ["mylerz", "sprint", "r2s"].includes(selectedCompany.id) && (
                <>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">مفتاح الربط (API Key)</label>
                    <input 
                      type="password"
                      value={apiKeys[`${selectedCompany.id}_apiKey`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_apiKey`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">معرف التاجر (Merchant ID)</label>
                    <input 
                      type="text"
                      value={apiKeys[`${selectedCompany.id}_merchantId`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedCompany.id}_merchantId`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                </>
              )}

              {/* Payment Specific Fields (Kashier) */}
              {configType === "payment" && selectedPaymentGateway && selectedPaymentGateway.id === "kashier" && (
                <>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">معرف التاجر (Merchant ID)</label>
                    <input 
                      type="text"
                      placeholder="MID-0000-0000"
                      value={apiKeys[`${selectedPaymentGateway.id}_merchantId`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedPaymentGateway.id}_merchantId`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">المفتاح السري (Secret Key / API Key)</label>
                    <input 
                      type="password"
                      placeholder="sk_test_..."
                      value={apiKeys[`${selectedPaymentGateway.id}_apiKey`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedPaymentGateway.id}_apiKey`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                  
                  {/* Redirect URLs for Payment Gateways */}
                  <div className="pt-4 border-t border-slate-100">
                    <label className="block text-sm font-bold text-slate-700 mb-2">رابط التوجيه بعد الدفع (Callback URL)</label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="text"
                        readOnly
                        value={`https://yourdomain.com/checkout/callback/${selectedPaymentGateway.id}`}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-500 text-left font-mono text-xs outline-none"
                        dir="ltr"
                      />
                      <button 
                        onClick={() => handleCopy(`https://yourdomain.com/checkout/callback/${selectedPaymentGateway.id}`, 'callback')}
                        className="p-2.5 bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 rounded-xl transition-colors shrink-0"
                        title="نسخ الرابط"
                      >
                        {copiedId === 'callback' ? (
                          <CheckCircle2 className="w-[18px] h-[18px] text-emerald-600" />
                        ) : (
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                        )}
                      </button>
                    </div>
                  </div>
                </>
              )}

              {/* Payment Specific Fields (Paymob, Fawry, etc.) */}
              {configType === "payment" && selectedPaymentGateway && ["paymob", "fawry"].includes(selectedPaymentGateway.id) && (
                <>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">مفتاح الربط (API Key)</label>
                    <input 
                      type="password"
                      value={apiKeys[`${selectedPaymentGateway.id}_apiKey`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedPaymentGateway.id}_apiKey`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">معرف التاجر (Merchant ID)</label>
                    <input 
                      type="text"
                      value={apiKeys[`${selectedPaymentGateway.id}_merchantId`] || ""}
                      onChange={(e) => setApiKeys({...apiKeys, [`${selectedPaymentGateway.id}_merchantId`]: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-slate-900 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none transition-all"
                    />
                  </div>
                </>
              )}

              {/* Webhook Section */}
              <div className="pt-4 border-t border-slate-100">
                <label className="block text-sm font-bold text-slate-700 mb-2">رابط التحديثات التلقائية (Webhook URL)</label>
                <div className="flex items-center gap-2">
                  <input 
                    type="text"
                    readOnly
                    value={`https://api.yourdomain.com/webhooks/${configType}/${configType === "shipping" ? selectedCompany?.id : selectedPaymentGateway?.id}`}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-500 text-left font-mono text-xs outline-none"
                    dir="ltr"
                  />
                  <button 
                    onClick={() => handleCopy(`https://api.yourdomain.com/webhooks/${configType}/${configType === "shipping" ? selectedCompany?.id : selectedPaymentGateway?.id}`, 'webhook')}
                    className="p-2.5 bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 rounded-xl transition-colors shrink-0"
                    title="نسخ الرابط"
                  >
                    {copiedId === 'webhook' ? (
                      <CheckCircle2 className="w-[18px] h-[18px] text-emerald-600" />
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 font-medium">
                  انسخ هذا الرابط وأضفه في لوحة تحكم {configType === "shipping" ? selectedCompany?.name : selectedPaymentGateway?.name} لتفعيل التحديث التلقائي للحالات.
                </p>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3 rounded-b-2xl">
              <button 
                onClick={closeConfigModal}
                className="px-5 py-2.5 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
              >
                إلغاء
              </button>
              <button 
                onClick={saveConfig}
                className="px-5 py-2.5 text-sm font-bold text-white bg-slate-900 rounded-xl hover:bg-slate-800 shadow-lg shadow-slate-900/20 transition-all flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                حفظ الإعدادات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
