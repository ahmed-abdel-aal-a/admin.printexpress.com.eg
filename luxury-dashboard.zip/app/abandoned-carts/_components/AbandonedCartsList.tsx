"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import { AbandonedCart, CartStatus } from "../types";
import { mockAbandonedCarts } from "../mock-data";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { Eye, MessageCircle, Mail, BellRing, Tag, ChevronRight, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const statusConfig: Record<CartStatus, { label: string; color: string }> = {
  pending: { label: "قيد الانتظار", color: "bg-amber-100 text-amber-800 border-amber-200" },
  recovered: { label: "مسترجعة", color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  lost: { label: "مفقودة", color: "bg-rose-100 text-rose-800 border-rose-200" },
};

export default function AbandonedCartsList() {
  const [carts, setCarts] = useState<AbandonedCart[]>(mockAbandonedCarts);
  const [filter, setFilter] = useState<CartStatus | 'all'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const filteredCarts = useMemo(() => {
    return filter === 'all' ? carts : carts.filter(c => c.status === filter);
  }, [carts, filter]);

  const totalPages = Math.ceil(filteredCarts.length / itemsPerPage);
  const paginatedCarts = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredCarts.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredCarts, currentPage]);

  const handleFilterChange = (newFilter: CartStatus | 'all') => {
    setFilter(newFilter);
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex gap-2 overflow-x-auto pb-2 w-full sm:w-auto">
          <Button 
            variant={filter === 'all' ? 'default' : 'outline'} 
            onClick={() => handleFilterChange('all')}
            className={filter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-600'}
          >
            الكل
          </Button>
          <Button 
            variant={filter === 'pending' ? 'default' : 'outline'} 
            onClick={() => handleFilterChange('pending')}
            className={filter === 'pending' ? 'bg-amber-600 text-white' : 'text-slate-600'}
          >
            قيد الانتظار
          </Button>
          <Button 
            variant={filter === 'recovered' ? 'default' : 'outline'} 
            onClick={() => handleFilterChange('recovered')}
            className={filter === 'recovered' ? 'bg-emerald-600 text-white' : 'text-slate-600'}
          >
            مسترجعة
          </Button>
          <Button 
            variant={filter === 'lost' ? 'default' : 'outline'} 
            onClick={() => handleFilterChange('lost')}
            className={filter === 'lost' ? 'bg-rose-600 text-white' : 'text-slate-600'}
          >
            مفقودة
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-medium">
              <tr>
                <th className="px-6 py-4">العميل</th>
                <th className="px-6 py-4">نوع العميل</th>
                <th className="px-6 py-4">القيمة</th>
                <th className="px-6 py-4">تاريخ الترك</th>
                <th className="px-6 py-4">الحالة</th>
                <th className="px-6 py-4">إجراءات سريعة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedCarts.map((cart) => (
                <tr key={cart.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-bold text-slate-800 flex items-center gap-2">
                      {cart.customerName || "غير معروف"}
                      {cart.offeredDiscount && (
                        <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px]" title="تم عرض خصم">
                          <Tag className="w-3 h-3" />
                          خصم
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 mt-1">{cart.customerEmail || cart.customerPhone || "لا يوجد تواصل"}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-slate-600 bg-slate-100 px-2 py-1 rounded-md text-xs">
                      {cart.customerType === 'registered' ? 'مسجل' : cart.customerType === 'guest' ? 'زائر (بيانات محفوظة)' : 'مجهول'}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-800">
                    {cart.totalAmount} ج.م
                  </td>
                  <td className="px-6 py-4 text-slate-600 text-xs">
                    {format(new Date(cart.abandonedAt), 'PP p', { locale: ar })}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${statusConfig[cart.status].color}`}>
                      {statusConfig[cart.status].label}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Link href={`/abandoned-carts/${cart.id}`}>
                        <Button variant="outline" size="icon" className="h-8 w-8 text-slate-600 hover:text-amber-600">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Button variant="outline" size="icon" className="h-8 w-8 text-green-600 hover:bg-green-50" title="إرسال واتساب" disabled={!cart.customerPhone}>
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8 text-blue-600 hover:bg-blue-50" title="إرسال بريد" disabled={!cart.customerEmail}>
                        <Mail className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8 text-amber-600 hover:bg-amber-50" title="إشعار متصفح" disabled={!cart.hasPushPermission}>
                        <BellRing className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {paginatedCarts.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                    لا توجد سلات متروكة تطابق الفلتر الحالي.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {totalPages > 1 && (
          <div className="border-t border-slate-200 px-6 py-4 flex items-center justify-between">
            <div className="text-sm text-slate-500">
              صفحة {currentPage} من {totalPages}
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="gap-1 text-slate-600"
              >
                <ChevronRight className="w-4 h-4" />
                السابق
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="gap-1 text-slate-600"
              >
                التالي
                <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
