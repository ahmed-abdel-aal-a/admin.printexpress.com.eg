export type CartStatus = 'pending' | 'recovered' | 'lost';
export type CustomerType = 'registered' | 'guest' | 'anonymous';

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  isSaleItem?: boolean;
}

export interface OfferedDiscount {
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  expiresAt?: string;
}

export interface AbandonedCart {
  id: string;
  customerId?: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  customerType: CustomerType;
  items: CartItem[];
  totalAmount: number;
  abandonedAt: string;
  status: CartStatus;
  recoveryUrl: string;
  lastContactedAt?: string;
  contactHistory: ContactEvent[];
  offeredDiscount?: OfferedDiscount;
  hasPushPermission?: boolean;
}

export interface ContactEvent {
  id: string;
  type: 'whatsapp' | 'email' | 'sms' | 'push';
  sentAt: string;
  status: 'sent' | 'delivered' | 'failed' | 'clicked';
}

export interface AbandonedCartsSettings {
  considerAbandonedAfterMinutes: number;
  frequencyCappingHours: number;
  enablePushNotifications: boolean;
  pushNotificationTitle: string;
  pushNotificationBody: string;
  whatsappTemplate: string;
  emailSubject: string;
  emailTemplate: string;
  enableDiscounts: boolean;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  antiAbuseDays: number;
  excludeSaleItems: boolean;
}

