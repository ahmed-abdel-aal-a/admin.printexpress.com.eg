import { AbandonedCart, AbandonedCartsSettings } from "./types";

export const mockAbandonedCarts: AbandonedCart[] = [
  {
    id: "cart_001",
    customerId: "cust_123",
    customerName: "أحمد محمود",
    customerEmail: "ahmed@example.com",
    customerPhone: "+201000000000",
    customerType: "registered",
    items: [
      {
        id: "item_1",
        productId: "prod_1",
        name: "عطر ليالي الشرق",
        price: 250,
        quantity: 2,
        image: "https://picsum.photos/seed/perfume1/100/100",
      },
      {
        id: "item_2",
        productId: "prod_2",
        name: "ساعة فاخرة",
        price: 1500,
        quantity: 1,
        image: "https://picsum.photos/seed/watch1/100/100",
        isSaleItem: true
      }
    ],
    totalAmount: 2000,
    abandonedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
    status: "pending",
    recoveryUrl: "https://luxury.store/checkout/recover/cart_001",
    contactHistory: []
  },
  {
    id: "cart_002",
    customerName: "زائر (تخزين مؤقت)",
    customerEmail: "visitor_guest@example.com",
    customerPhone: "+201111111111",
    customerType: "guest",
    items: [
      {
        id: "item_3",
        productId: "prod_3",
        name: "حقيبة يد جلدية",
        price: 850,
        quantity: 1,
        image: "https://picsum.photos/seed/bag1/100/100",
      }
    ],
    totalAmount: 850,
    abandonedAt: new Date(Date.now() - 1000 * 60 * 60 * 25).toISOString(), // 25 hours ago
    status: "lost",
    recoveryUrl: "https://luxury.store/checkout/recover/cart_002",
    lastContactedAt: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
    contactHistory: [
      {
        id: "ev_1",
        type: "whatsapp",
        sentAt: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
        status: "delivered"
      }
    ]
  },
  {
    id: "cart_003",
    customerType: "anonymous",
    items: [
      {
        id: "item_4",
        productId: "prod_4",
        name: "محفظة رجالي",
        price: 300,
        quantity: 1,
        image: "https://picsum.photos/seed/wallet1/100/100",
      }
    ],
    totalAmount: 300,
    abandonedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
    status: "pending",
    recoveryUrl: "https://luxury.store/checkout/recover/cart_003",
    contactHistory: []
  },
  {
    id: "cart_004",
    customerId: "cust_456",
    customerName: "سارة كمال",
    customerEmail: "sara@example.com",
    customerPhone: "+201222222222",
    customerType: "registered",
    items: [
      {
        id: "item_5",
        productId: "prod_5",
        name: "نظارة شمسية",
        price: 600,
        quantity: 1,
        image: "https://picsum.photos/seed/glasses1/100/100",
      }
    ],
    totalAmount: 600,
    abandonedAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), // 5 hours ago
    status: "recovered",
    recoveryUrl: "https://luxury.store/checkout/recover/cart_004",
    lastContactedAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    contactHistory: [
      {
        id: "ev_2",
        type: "push",
        sentAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
        status: "clicked"
      },
      {
        id: "ev_3",
        type: "email",
        sentAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
        status: "delivered"
      }
    ]
  }
];

export const mockSettings: AbandonedCartsSettings = {
  considerAbandonedAfterMinutes: 60,
  frequencyCappingHours: 24,
  enablePushNotifications: true,
  pushNotificationTitle: "نسيت شيئاً في سلتك؟ 🛒",
  pushNotificationBody: "المنتجات التي اخترتها لا تزال بانتظارك، أكمل طلبك الآن قبل نفاذ الكمية!",
  whatsappTemplate: "مرحباً {{name}}، لاحظنا أنك تركت بعض المنتجات الرائعة في سلتك. استخدم هذا الرابط لإكمال طلبك: {{url}}\n\nاستخدم الكود {{discountCode}} للحصول على خصم خاص!",
  emailSubject: "سلتك في انتظارك!",
  emailTemplate: "مرحباً {{name}}،\n\nلقد تركت بعض المنتجات في سلتك. لا تفوت الفرصة وأكمل طلبك الآن.\n\nاستخدم الكود {{discountCode}} للحصول على خصم خاص!\n\nرابط السلة: {{url}}",
  enableDiscounts: true,
  discountType: 'percentage',
  discountValue: 10,
  antiAbuseDays: 30,
  excludeSaleItems: true
};
