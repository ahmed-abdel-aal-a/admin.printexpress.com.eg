import { mockAbandonedCarts } from "../mock-data";

export function generateStaticParams() {
  return mockAbandonedCarts.map((cart) => ({
    id: cart.id,
  }));
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
