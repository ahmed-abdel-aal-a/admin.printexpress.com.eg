"use client";

import React, { use, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { ArrowRight, ShoppingCart, Calendar, Mail, MessageCircle, BellRing, Phone, User, Clock, CheckCircle2, AlertCircle, Tag } from "lucide-react";
import { mockAbandonedCarts } from "../mock-data";
import { Button } from "@/components/ui/button";
import { OfferedDiscount } from "../types";

export default function AbandonedCartDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const cart = mockAbandonedCarts.find(c => c.id === resolvedParams.id);
  const [discount, setDiscount] = useState<OfferedDiscount | undefined>(cart?.offeredDiscount);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateDiscount = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setDiscount({
        code: `SAVE${Math.floor(Math.random() * 10000)}`,
        type: 'percentage',
        value: 10
      });
      setIsGenerating(false);
    }, 600);
  };

  if (!cart) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <ShoppingCart className="w-16 h-16 text-slate-300" />
        <h2 className="text-2xl font-bold text-slate-800">السلة غير موجودة</h2>
        <p className="text-slate-500">لم نتمكن من العثور على السلة المتروكة المطلوبة.</p>
        <Link href="/abandoned-carts">
          <Button variant="outline">العودة للقائمة</Button>
        </Link>
      </div>
    );
  }

  const getStatusBadge = () => {
    switch(cart.status) {
      case 'pending': return <span className="bg-amber-100 text-amber-800 border border-amber-200 px-3 py-1 rounded-full text-sm font-medium">قيد الانتظار</span>;
      case 'recovered': return <span className="bg-emerald-100 text-emerald-800 border border-emerald-200 px-3 py-1 rounded-full text-sm font-medium">مسترجعة</span>;
      case 'lost': return <span className="bg-rose-100 text-rose-800 border border-rose-200 px-3 py-1 rounded-full text-sm font-medium">مفقودة</span>;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/abandoned-carts">
            <Button variant="outline" size="icon" className="h-10 w-10 shrink-0">
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-3">
              تفاصيل السلة #{cart.id}
            </h1>
            <p className="text-sm text-slate-500 mt-1 flex items-center gap-2">
              <Clock className="w-4 h-4" /> 
              تركت في {format(new Date(cart.abandonedAt), 'PP p', { locale: ar })}
            </p>
          </div>
        </div>
        <div>
          {getStatusBadge()}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Customer & Actions */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b border-slate-100 pb-4">معلومات العميل</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-slate-700">
                <User className="w-5 h-5 text-slate-400" />
                <span className="font-medium">{cart.customerName || 'غير متوفر'}</span>
                <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full mr-auto">
                  {cart.customerType === 'registered' ? 'مسجل' : cart.customerType === 'guest' ? 'زائر' : 'مجهول'}
                </span>
              </div>
              {cart.customerPhone && (
                <div className="flex items-center gap-3 text-slate-700">
                  <Phone className="w-5 h-5 text-slate-400" />
                  <span dir="ltr">{cart.customerPhone}</span>
                </div>
              )}
              {cart.customerEmail && (
                <div className="flex items-center gap-3 text-slate-700">
                  <Mail className="w-5 h-5 text-slate-400" />
                  <span>{cart.customerEmail}</span>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b border-slate-100 pb-4">إجراءات الاسترجاع</h3>
            
            {/* Discount Section */}
            <div className="mb-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
                <Tag className="w-4 h-4 text-amber-600" />
                الخصم التحفيزي
              </h4>
              {discount ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between bg-white p-2 rounded border border-slate-200">
                    <span className="font-mono text-amber-700 font-bold">{discount.code}</span>
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">
                      {discount.type === 'percentage' ? `${discount.value}% خصم` : `${discount.value} ج.م خصم`}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 text-center">الكود جاهز للإرسال في القوالب التلقائية</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">لم يتم توليد كود خصم لهذه السلة.</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full border-amber-200 text-amber-700 hover:bg-amber-50"
                    onClick={generateDiscount}
                    disabled={isGenerating}
                  >
                    {isGenerating ? "جاري التوليد..." : "توليد كود خصم خاص"}
                  </Button>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <Button className="w-full justify-start gap-3 bg-[#25D366] hover:bg-[#128C7E] text-white" disabled={!cart.customerPhone}>
                <MessageCircle className="w-5 h-5" />
                إرسال رسالة واتساب
              </Button>
              <Button className="w-full justify-start gap-3 bg-blue-600 hover:bg-blue-700 text-white" disabled={!cart.customerEmail}>
                <Mail className="w-5 h-5" />
                إرسال بريد إلكتروني
              </Button>
              <Button className="w-full justify-start gap-3 bg-amber-600 hover:bg-amber-700 text-white" disabled={cart.customerType === 'anonymous'}>
                <BellRing className="w-5 h-5" />
                إرسال إشعار للمتصفح (Push)
              </Button>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100">
              <p className="text-xs text-slate-500 mb-2">رابط الاسترجاع السريع:</p>
              <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-200">
                <input 
                  type="text" 
                  readOnly 
                  value={cart.recoveryUrl} 
                  className="bg-transparent border-none text-xs w-full text-slate-600 focus:outline-none" 
                />
                <Button variant="ghost" size="sm" className="h-6 text-xs text-amber-600 hover:text-amber-700 hover:bg-amber-50">نسخ</Button>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b border-slate-100 pb-4">سجل التواصل</h3>
            {cart.contactHistory.length > 0 ? (
              <div className="space-y-4 relative before:absolute before:inset-y-0 before:right-2.5 before:w-0.5 before:bg-slate-100">
                {cart.contactHistory.map((ev, idx) => (
                  <div key={ev.id} className="relative flex gap-4 pl-4 items-start">
                    <div className="w-5 h-5 rounded-full bg-white border-2 border-amber-500 flex-shrink-0 z-10 mt-0.5"></div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">
                        {ev.type === 'whatsapp' ? 'واتساب' : ev.type === 'email' ? 'بريد إلكتروني' : ev.type === 'push' ? 'إشعار متصفح' : 'رسالة قصيرة'}
                      </p>
                      <p className="text-xs text-slate-500 mt-1">{format(new Date(ev.sentAt), 'PP p', { locale: ar })}</p>
                      <div className="mt-1">
                        {ev.status === 'delivered' || ev.status === 'clicked' ? (
                          <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> {ev.status === 'clicked' ? 'تم النقر' : 'تم الاستلام'}</span>
                        ) : ev.status === 'failed' ? (
                          <span className="text-[10px] text-rose-600 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3"/> فشل الإرسال</span>
                        ) : (
                          <span className="text-[10px] text-amber-600 font-medium flex items-center gap-1">تم الإرسال</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-500 text-center py-4">لم يتم إرسال أي تذكيرات بعد.</p>
            )}
          </div>
        </div>

        {/* Right Column: Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-800">محتويات السلة</h3>
              <span className="bg-slate-100 text-slate-700 px-3 py-1 rounded-lg text-sm font-bold">
                {cart.items.length} منتجات
              </span>
            </div>
            <div className="divide-y divide-slate-100">
              {cart.items.map((item) => (
                <div key={item.id} className="p-6 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                  <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 border border-slate-200 relative">
                    <Image src={item.image} alt={item.name} fill className="object-cover" unoptimized />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-800 text-base">{item.name}</h4>
                      {item.isSaleItem && (
                        <span className="bg-rose-100 text-rose-700 text-[10px] font-bold px-2 py-0.5 rounded-full">تخفيضات</span>
                      )}
                    </div>
                    <p className="text-slate-500 text-sm mt-1">الكمية: {item.quantity}</p>
                  </div>
                  <div className="text-left shrink-0">
                    <p className="font-bold text-slate-800 text-lg">{item.price * item.quantity} ج.م</p>
                    {item.quantity > 1 && (
                      <p className="text-slate-400 text-xs mt-1">{item.price} ج.م للوحدة</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-6 bg-slate-50 flex justify-between items-center border-t border-slate-200">
              <span className="text-slate-600 font-medium text-lg">الإجمالي</span>
              <span className="font-bold text-2xl text-slate-800">{cart.totalAmount} ج.م</span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
