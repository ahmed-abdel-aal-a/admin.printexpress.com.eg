"use client";

import React from "react";

import { useState } from "react";

import {
  Search,
  ListFilter,
  Download,
  MoreVertical,
  Printer,
  Eye,
  Trash2,
  CheckCircle2,
  Clock,
  Truck,
  Ban,
  AlertCircle,
  RefreshCcw,
  PackageSearch,
  ChevronDown,
  Calendar,
  CreditCard,
  Box,
  BarChart3,
} from "lucide-react";

import { cn } from "@/lib/utils";

import { Button } from "@/components/ui/button";

import { Input } from "@/components/ui/input";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Types for Orders
type OrderStatus =
  | "needs_action"
  | "confirmed"
  | "in_progress"
  | "shipped"
  | "completed"
  | "cancelled"
  | "trash";

type PaymentStatus = "paid" | "unpaid" | "cod" | "refunded";

interface Order {
  id: string;

  customerName: string;

  customerPhone: string;

  date: string;

  total: number;

  itemsCount: number;

  status: OrderStatus;

  paymentStatus: PaymentStatus;

  shippingCompany?: string;

  trackingNumber?: string;
}

// Dummy Data
const MOCK_ORDERS: Order[] = [
  {
    id: "#ORD-9821",
    customerName: "أحمد محمود",
    customerPhone: "0501234567",
    date: "2026-07-14 10:30 ص",
    total: 1250,
    itemsCount: 3,
    status: "needs_action",
    paymentStatus: "unpaid",
  },
  {
    id: "#ORD-9820",
    customerName: "سارة خالد",
    customerPhone: "0559876543",
    date: "2026-07-14 09:15 ص",
    total: 450,
    itemsCount: 1,
    status: "needs_action",
    paymentStatus: "paid",
  },
  {
    id: "#ORD-9819",
    customerName: "محمد عبدالله",
    customerPhone: "0541122334",
    date: "2026-07-13 11:20 م",
    total: 3200,
    itemsCount: 5,
    status: "confirmed",
    paymentStatus: "paid",
  },
  {
    id: "#ORD-9818",
    customerName: "نورة السالم",
    customerPhone: "0569988776",
    date: "2026-07-13 08:45 م",
    total: 150,
    itemsCount: 1,
    status: "in_progress",
    paymentStatus: "cod",
  },
  {
    id: "#ORD-9817",
    customerName: "عبدالرحمن فهد",
    customerPhone: "0597766554",
    date: "2026-07-13 04:30 م",
    total: 890,
    itemsCount: 2,
    status: "shipped",
    paymentStatus: "paid",
    shippingCompany: "أرامكس",
    trackingNumber: "ARX99887766",
  },
  {
    id: "#ORD-9816",
    customerName: "فاطمة علي",
    customerPhone: "0533344556",
    date: "2026-07-12 02:10 م",
    total: 2100,
    itemsCount: 4,
    status: "completed",
    paymentStatus: "paid",
    shippingCompany: "سمسا",
    trackingNumber: "SMSA112233",
  },
  {
    id: "#ORD-9815",
    customerName: "يوسف السعيد",
    customerPhone: "0500001111",
    date: "2026-07-11 06:00 م",
    total: 500,
    itemsCount: 2,
    status: "cancelled",
    paymentStatus: "refunded",
  },
  {
    id: "#ORD-9814",
    customerName: "ريم المطيري",
    customerPhone: "0511112222",
    date: "2026-07-10 12:00 م",
    total: 750,
    itemsCount: 1,
    status: "trash",
    paymentStatus: "unpaid",
  },
];

const STATUS_TABS: {
  id: OrderStatus;
  label: string;
  icon: React.ElementType;
  count: number;
  color: string;
}[] = [
  {
    id: "needs_action",
    label: "تحتاج إجراء",
    icon: AlertCircle,
    count: 2,
    color: "text-rose-600 bg-rose-50 border-rose-200",
  },
  {
    id: "confirmed",
    label: "تم التأكيد",
    icon: CheckCircle2,
    count: 1,
    color: "text-blue-600 bg-blue-50 border-blue-200",
  },
  {
    id: "in_progress",
    label: "قيد التنفيذ",
    icon: RefreshCcw,
    count: 1,
    color: "text-amber-600 bg-amber-50 border-amber-200",
  },
  {
    id: "shipped",
    label: "مشحونة",
    icon: Truck,
    count: 1,
    color: "text-indigo-600 bg-indigo-50 border-indigo-200",
  },
  {
    id: "completed",
    label: "مكتملة",
    icon: Box,
    count: 1,
    color: "text-emerald-600 bg-emerald-50 border-emerald-200",
  },
  {
    id: "cancelled",
    label: "ملغية/مسترد",
    icon: Ban,
    count: 1,
    color: "text-slate-600 bg-slate-50 border-slate-200",
  },
  {
    id: "trash",
    label: "المهملات",
    icon: Trash2,
    count: 1,
    color: "text-slate-400 bg-slate-50 border-slate-200",
  },
];

export default function OrdersPage() {
  const [activeTab, setActiveTab] = useState<OrderStatus>("needs_action");

  const [searchQuery, setSearchQuery] = useState("");

  // ListFilter logic
  const filteredOrders = MOCK_ORDERS.filter(
    (order) =>
      order.status === activeTab &&
      (order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.customerName.includes(searchQuery) ||
        order.customerPhone.includes(searchQuery)),
  );

  return (
    <div className="min-h-screen bg-slate-50/50 pb-20 md:pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-1.5">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              الطلبات
            </h1>
            <p className="text-slate-500 text-sm sm:text-base max-w-xl">
              إدارة ومتابعة دورة حياة الطلبات من التأكيد إلى التسليم.
            </p>
          </div>
          <div className="flex items-center gap-3 w-full md:w-auto">
            <Button
              variant="outline"
              className="bg-white gap-2 flex-1 md:flex-none h-11 sm:h-10 rounded-xl sm:rounded-lg"
            >
              <Download className="w-4 h-4" />
              <span className="font-medium">تصدير</span>
            </Button>
            <Button className="bg-slate-900 text-white hover:bg-slate-800 gap-2 flex-1 md:flex-none shadow-md h-11 sm:h-10 rounded-xl sm:rounded-lg transition-transform active:scale-95">
              <PlusIcon className="w-4 h-4" />
              <span className="font-medium">طلب جديد</span>
            </Button>
          </div>
        </div>

        {/* Quick Stats - Desktop */}
        <div className="hidden lg:grid grid-cols-4 gap-4">
          <StatCard
            title="إجمالي الطلبات"
            value="1,284"
            trend="+12%"
            type="neutral"
          />
          <StatCard title="تحتاج إجراء" value="14" type="warning" />
          <StatCard title="مشحونة اليوم" value="45" type="info" />
          <StatCard
            title="المبيعات (ر.س)"
            value="24,500"
            trend="+8%"
            type="success"
          />
        </div>

        {/* Quick Stats - Mobile */}
        <div className="lg:hidden">
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="w-full bg-white justify-between h-[52px] rounded-2xl border-orange-200 bg-orange-50/30 hover:bg-orange-50 text-orange-800 shadow-sm transition-all active:scale-[0.98]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-orange-100 flex items-center justify-center">
                    <AlertCircle className="w-4.5 h-4.5 text-orange-600" />
                  </div>
                  <div className="flex flex-col items-start">
                    <span className="font-bold text-sm">تحتاج إجراء</span>
                    <span className="text-[10px] text-orange-600/80 font-medium">
                      عرض ملخص الإحصائيات
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="bg-orange-500 text-white text-xs font-bold px-2.5 py-1 rounded-lg shadow-sm">
                    14
                  </span>
                  <BarChart3 className="w-4 h-4 text-orange-400" />
                </div>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md rounded-3xl p-0 overflow-hidden border-slate-100">
              <DialogHeader className="bg-slate-50/50 pt-8 pb-4">
                <DialogTitle className="text-xl">
                  ملخص الطلبات والإحصائيات
                </DialogTitle>
              </DialogHeader>
              <div className="p-5 grid grid-cols-2 gap-3 bg-slate-50/30">
                <StatCard
                  title="إجمالي الطلبات"
                  value="1,284"
                  trend="+12%"
                  type="neutral"
                />
                <StatCard title="تحتاج إجراء" value="14" type="warning" />
                <StatCard title="مشحونة اليوم" value="45" type="info" />
                <StatCard
                  title="المبيعات"
                  value="24,500"
                  trend="+8%"
                  type="success"
                />
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Main Content Area */}
        <div className="bg-white rounded-2xl sm:rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
          {/* Tabs - Desktop */}
          <div className="hidden lg:block border-b border-slate-100 w-full overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
            <div className="flex p-2 sm:p-3 min-w-max gap-1 sm:gap-2">
              {STATUS_TABS.map((tab) => {
                const isActive = activeTab === tab.id;

                const Icon = tab.icon;

                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl text-sm font-medium transition-all duration-200 select-none",
                      isActive
                        ? "bg-slate-900 text-white shadow-md ring-1 ring-slate-900/10"
                        : "text-slate-500 hover:bg-slate-50 hover:text-slate-900",
                    )}
                  >
                    <Icon
                      className={cn(
                        "w-4 h-4",
                        isActive ? "text-slate-300" : "text-slate-400",
                      )}
                    />
                    <span className="whitespace-nowrap">{tab.label}</span>
                    <span
                      className={cn(
                        "flex items-center justify-center text-[10px] font-bold px-1.5 min-w-[20px] h-5 rounded-full transition-colors",
                        isActive
                          ? "bg-white/20 text-white"
                          : "bg-slate-100 text-slate-500 group-hover:bg-slate-200",
                      )}
                    >
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tabs - Mobile (Select) */}
          <div className="lg:hidden p-4 border-b border-slate-100 bg-slate-50/30">
            <Select
              value={activeTab}
              onValueChange={(v) => setActiveTab(v as OrderStatus)}
            >
              <SelectTrigger className="w-full bg-white h-12 text-sm font-bold shadow-sm border-slate-200">
                <SelectValue placeholder="اختر حالة الطلب" />
              </SelectTrigger>
              <SelectContent className="rounded-2xl">
                {STATUS_TABS.map((tab) => {
                  const Icon = tab.icon;

                  return (
                    <SelectItem
                      key={tab.id}
                      value={tab.id}
                      className="text-sm font-semibold py-3"
                    >
                      <div className="flex items-center justify-between w-full pr-1">
                        <div className="flex items-center gap-2.5">
                          <Icon
                            className={cn("w-4 h-4", tab.color.split(" ")[0])}
                          />
                          <span>{tab.label}</span>
                        </div>
                        <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded-full mr-4">
                          {tab.count}
                        </span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Filters & Actions bar */}
          <div className="p-3 sm:p-4 border-b border-slate-100 flex flex-col lg:flex-row gap-3 items-center justify-between bg-white">
            <div className="relative w-full lg:max-w-md">
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                type="text"
                placeholder="ابحث برقم الطلب، اسم العميل..."
                className="pl-4 pr-10 bg-white border-slate-200 shadow-sm w-full h-11 sm:h-10 focus-visible:ring-slate-400 rounded-xl"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="flex items-center gap-2 w-full lg:w-auto overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] pb-1 lg:pb-0">
              <Button
                variant="outline"
                size="sm"
                className="h-10 sm:h-9 gap-2 bg-white rounded-xl sm:rounded-lg whitespace-nowrap border-slate-200"
              >
                <Calendar className="w-4 h-4 text-slate-500" />
                <span className="font-medium text-slate-700">التاريخ</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-10 sm:h-9 gap-2 bg-white rounded-xl sm:rounded-lg whitespace-nowrap border-slate-200"
              >
                <CreditCard className="w-4 h-4 text-slate-500" />
                <span className="font-medium text-slate-700">الدفع</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-10 sm:h-9 gap-2 bg-white rounded-xl sm:rounded-lg whitespace-nowrap border-slate-200 lg:hidden"
              >
                <ListFilter className="w-4 h-4 text-slate-500" />
                <span className="font-medium text-slate-700">تصفية</span>
              </Button>
            </div>
          </div>

          {/* Data Presentation */}
          <div className="flex-1 overflow-auto bg-slate-50/30">
            {filteredOrders.length === 0 ? (
              <EmptyState searchQuery={searchQuery} onClearSearch={() => setSearchQuery("")} />
            ) : (
              <>
                {/* Desktop Table View */}
                <div className="hidden lg:block w-full">
                  <table className="w-full text-sm text-right">
                    <thead className="bg-slate-100 text-slate-500 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-4 rounded-tr-xl">رقم الطلب</th>
                        <th className="px-6 py-4">العميل</th>
                        <th className="px-6 py-4">التاريخ</th>
                        <th className="px-6 py-4">حالة الدفع</th>
                        <th className="px-6 py-4">الإجمالي</th>
                        {["shipped", "completed"].includes(activeTab) && (
                          <th className="px-6 py-4">الشحن</th>
                        )}
                        <th className="px-6 py-4 rounded-tl-xl w-24">إجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredOrders.map((order) => (
                        <tr
                          key={order.id}
                          className="hover:bg-white transition-colors group"
                        >
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="font-semibold text-slate-900 cursor-pointer hover:text-amber-600 transition-colors">
                              {order.id}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex flex-col">
                              <span className="font-medium text-slate-900">
                                {order.customerName}
                              </span>
                              <span
                                className="text-xs text-slate-500 mt-0.5"
                                dir="ltr"
                              >
                                {order.customerPhone}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-1.5 text-slate-500">
                              <Clock className="w-3.5 h-3.5" />
                              <span className="text-xs">{order.date}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <PaymentBadge status={order.paymentStatus} />
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col">
                              <span className="font-bold text-slate-900">
                                {order.total.toLocaleString()} ر.س
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {order.itemsCount} منتجات
                              </span>
                            </div>
                          </td>
                          {["shipped", "completed"].includes(activeTab) && (
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex flex-col">
                                <span className="font-medium text-slate-700 text-xs">
                                  {order.shippingCompany || "-"}
                                </span>
                                <span className="text-[10px] text-blue-600 font-mono mt-0.5">
                                  {order.trackingNumber || ""}
                                </span>
                              </div>
                            </td>
                          )}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                              >
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile Cards View */}
                <div className="lg:hidden divide-y divide-slate-100">
                  {filteredOrders.map((order) => (
                    <div
                      key={order.id}
                      className="bg-white p-4 sm:p-5 hover:bg-slate-50/50 transition-colors"
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex flex-col gap-1.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-base">
                              {order.id}
                            </span>
                            <PaymentBadge status={order.paymentStatus} />
                          </div>
                          <div className="flex items-center gap-1.5 text-slate-500">
                            <Clock className="w-3.5 h-3.5" />
                            <span className="text-xs font-medium">
                              {order.date}
                            </span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 -mt-1 -mr-2 text-slate-400 hover:text-slate-900 rounded-lg"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex items-center gap-3 bg-slate-50/80 rounded-2xl p-3 mb-4 border border-slate-100/50">
                        <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-600 font-bold text-sm">
                          {order.customerName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm text-slate-900 truncate">
                            {order.customerName}
                          </p>
                          <p
                            className="text-xs text-slate-500 mt-0.5 truncate"
                            dir="ltr"
                          >
                            {order.customerPhone}
                          </p>
                        </div>
                      </div>

                      {["shipped", "completed"].includes(activeTab) &&
                        order.shippingCompany && (
                          <div className="mb-4 flex items-center justify-between border-y border-dashed border-slate-200 py-3">
                            <span className="text-xs font-medium text-slate-500">
                              الشحن عبر:{" "}
                              <span className="font-bold text-slate-800">
                                {order.shippingCompany}
                              </span>
                            </span>
                            <span className="text-xs text-indigo-600 font-mono bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                              {order.trackingNumber}
                            </span>
                          </div>
                        )}

                      <div className="flex items-end justify-between pt-1">
                        <div className="space-y-1">
                          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
                            الإجمالي ({order.itemsCount} منتجات)
                          </p>
                          <p className="font-black text-lg text-slate-900">
                            {order.total.toLocaleString()}{" "}
                            <span className="text-xs font-medium text-slate-500">
                              ر.س
                            </span>
                          </p>
                        </div>
                        <Button className="bg-slate-900 text-white rounded-xl text-xs font-medium h-9 px-4 shadow-sm hover:bg-slate-800 transition-colors">
                          التفاصيل
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Helpers
function PlusIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="M12 5v14" />
    </svg>
  );
}

function PaymentBadge({ status }: { status: PaymentStatus }) {
  const configs = {
    paid: {
      label: "مدفوع",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    },
    unpaid: {
      label: "غير مدفوع",
      className: "bg-rose-50 text-rose-700 border-rose-200",
    },
    cod: {
      label: "الدفع عند الاستلام",
      className: "bg-amber-50 text-amber-700 border-amber-200",
    },
    refunded: {
      label: "مسترد",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    },
  };

  const config = configs[status];

  return (
    <span
      className={cn(
        "px-2.5 py-1 rounded-md text-[10px] font-bold border",
        config.className,
      )}
    >
      {config.label}
    </span>
  );
}

function StatCard({
  title,
  value,
  trend,
  type,
}: {
  title: string;
  value: string;
  trend?: string;
  type: "neutral" | "warning" | "info" | "success";
}) {
  const styles = {
    neutral: "bg-white border-slate-200",
    warning: "bg-gradient-to-br from-rose-50 to-orange-50 border-orange-100",
    info: "bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100",
    success: "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-100",
  };

  return (
    <div
      className={cn(
        "p-5 rounded-2xl border shadow-sm flex flex-col justify-between",
        styles[type],
      )}
    >
      <p className="text-slate-500 text-xs font-medium mb-2">{title}</p>
      <div className="flex items-end justify-between">
        <p className="text-2xl font-black text-slate-900">{value}</p>
        {trend && (
          <span
            className={cn(
              "text-[10px] font-bold px-2 py-1 rounded-full",
              trend.startsWith("+")
                ? "bg-emerald-100 text-emerald-700"
                : "bg-rose-100 text-rose-700",
            )}
          >
            {trend}
          </span>
        )}
      </div>
    </div>
  );
}

function EmptyState({ searchQuery, onClearSearch }: { searchQuery: string; onClearSearch?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4 border border-slate-100">
        <PackageSearch className="w-10 h-10 text-slate-300" />
      </div>
      <h3 className="text-lg font-bold text-slate-900 mb-1">لا توجد طلبات</h3>
      <p className="text-sm text-slate-500 max-w-sm">
        {searchQuery
          ? `لم نتمكن من العثور على نتائج مطابقة لـ "${searchQuery}"`
          : "لا توجد طلبات في هذه الحالة حالياً. الطلبات الجديدة ستظهر هنا تلقائياً."}
      </p>
      {searchQuery && (
        <Button
          variant="outline"
          className="mt-6 rounded-xl"
          onClick={onClearSearch}
        >
          مسح البحث
        </Button>
      )}
    </div>
  );
}
