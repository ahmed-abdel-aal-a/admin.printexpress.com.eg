"use client";

import React from "react";

import {
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  Package,
  ShoppingCart,
  Users,
} from "lucide-react";

import Image from "next/image";

const stats = [
  {
    name: "إجمالي المبيعات",
    value: "124,500 ر.س",
    change: "+12.5%",
    trend: "up",
    icon: DollarSign,
  },
  {
    name: "الطلبات",
    value: "450",
    change: "+5.2%",
    trend: "up",
    icon: ShoppingCart,
  },
  {
    name: "المنتجات النشطة",
    value: "1,204",
    change: "-1.4%",
    trend: "down",
    icon: Package,
  },
  {
    name: "العملاء الجدد",
    value: "84",
    change: "+18.1%",
    trend: "up",
    icon: Users,
  },
];

export default function DashboardHome() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
          مرحباً بعودتك، أحمد 👋
        </h1>
        <p className="text-slate-500 mt-1 text-sm">
          إليك نظرة سريعة على أداء متجرك اليوم.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;

          return (
            <div
              key={index}
              className="bg-white rounded-3xl p-6 shadow-sm border border-white transition-transform hover:-translate-y-1 hover:shadow-md duration-300"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600">
                  <Icon className={"w-6 h-6"} />
                </div>
                <div
                  className={`flex items-center gap-1 text-sm font-bold ${stat.trend === "up" ? "text-emerald-600 bg-emerald-50" : "text-rose-600 bg-rose-50"} px-2.5 py-1 rounded-full`}
                >
                  {stat.trend === "up" ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {stat.change}
                </div>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                  {stat.name}
                </p>
                <h3 className="text-3xl font-black text-slate-800 tracking-tight">
                  {stat.value}
                </h3>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 shadow-sm border border-white">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-800">أحدث الطلبات</h2>
            <button className="text-sm font-bold text-amber-600 hover:text-amber-700">
              عرض الكل
            </button>
          </div>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:bg-slate-100/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white shadow-sm border border-slate-100 flex items-center justify-center font-bold text-slate-600">
                    {i}
                  </div>
                  <div>
                    <p className="font-bold text-slate-800">طلب #{1000 + i}</p>
                    <p className="text-xs text-slate-500">منذ ساعتين</p>
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-bold text-slate-800">450 ر.س</p>
                  <p className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded-full inline-block mt-1">
                    قيد المعالجة
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-white">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-800">
              المنتجات الأكثر مبيعاً
            </h2>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4">
                <Image
                  src={`https://picsum.photos/seed/${i + 10}/100/100`}
                  width={64}
                  height={64}
                  alt="Product"
                  className="w-16 h-16 rounded-2xl object-cover shadow-sm border border-slate-100"
                  referrerPolicy="no-referrer"
                  unoptimized
                />
                <div>
                  <h4 className="font-bold text-sm text-slate-800 line-clamp-2">
                    عطر فاخر أصدار محدود ({i})
                  </h4>
                  <p className="text-xs text-slate-500 mt-1 font-semibold">
                    {20 + i} مبيعة
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
