"use client";

import { useState } from "react";
import { Search, Send, User, MoreVertical, Image as ImageIcon, Smile } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Mock data
const CONVERSATIONS = [
  { id: 1, name: "أحمد محمد", lastMessage: "متى سيصل طلبي؟", time: "10:30 ص", unread: 2, online: true },
  { id: 2, name: "سارة علي", lastMessage: "شكراً لك، استلمت المنتج", time: "أمس", unread: 0, online: false },
  { id: 3, name: "محمود حسن", lastMessage: "هل يتوفر مقاس أكبر؟", time: "أمس", unread: 0, online: true },
];

const MESSAGES = [
  { id: 1, text: "مرحباً، قمت بطلب حذاء رياضي أمس وأريد معرفة موعد التوصيل.", sender: "customer", time: "10:25 ص" },
  { id: 2, text: "أهلاً بك أستاذ أحمد. سيتم توصيل طلبك خلال 48 ساعة من تاريخ الطلب.", sender: "agent", time: "10:28 ص" },
  { id: 3, text: "متى سيصل طلبي؟", sender: "customer", time: "10:30 ص" },
];

export default function LiveChat() {
  const [activeConv, setActiveConv] = useState(CONVERSATIONS[0].id);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState(MESSAGES);

  const activeUser = CONVERSATIONS.find((c) => c.id === activeConv);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      text: message.trim(),
      sender: "agent",
      time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages([...messages, newMessage]);
    setMessage("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden h-full min-h-[500px]">
      {/* Conversations List */}
      <div className="w-1/3 min-w-[280px] max-w-[320px] border-l border-slate-200 flex flex-col bg-slate-50/50">
        <div className="p-4 border-b border-slate-200">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="ابحث في المحادثات..."
              className="pl-3 pr-9 bg-white border-slate-200 rounded-xl"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {CONVERSATIONS.map((conv) => (
            <button
              key={conv.id}
              onClick={() => setActiveConv(conv.id)}
              className={cn(
                "w-full text-right p-4 border-b border-slate-100 transition-colors hover:bg-slate-50 flex gap-3",
                activeConv === conv.id ? "bg-amber-50/50 hover:bg-amber-50/80 relative" : ""
              )}
            >
              {activeConv === conv.id && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-amber-500" />
              )}
              <div className="relative">
                <div className="w-12 h-12 bg-slate-200 rounded-full flex items-center justify-center overflow-hidden shrink-0">
                  <User className="text-slate-400 w-6 h-6" />
                </div>
                {conv.online && (
                  <div className="absolute bottom-0 left-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                )}
              </div>
              <div className="flex-1 overflow-hidden">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-semibold text-slate-800 text-sm truncate">{conv.name}</h3>
                  <span className="text-xs text-slate-400 whitespace-nowrap mr-2">{conv.time}</span>
                </div>
                <p className="text-xs text-slate-500 truncate">{conv.lastMessage}</p>
              </div>
              {conv.unread > 0 && (
                <div className="w-5 h-5 bg-amber-500 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0 mt-1">
                  {conv.unread}
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-[#F8FAFC]">
        {/* Chat Header */}
        <div className="h-16 px-6 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center">
                <User className="text-slate-400 w-5 h-5" />
              </div>
              {activeUser?.online && (
                 <div className="absolute bottom-0 left-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full" />
              )}
            </div>
            <div>
              <h2 className="font-semibold text-slate-800">{activeUser?.name}</h2>
              <p className="text-xs text-slate-500">
                {activeUser?.online ? "متصل الآن" : "غير متصل"}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-slate-600">
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 p-6 overflow-y-auto custom-scrollbar flex flex-col gap-4">
          {messages.map((msg) => {
            const isAgent = msg.sender === "agent";
            return (
              <div
                key={msg.id}
                className={cn(
                  "flex flex-col max-w-[75%]",
                  isAgent ? "mr-auto items-end" : "ml-auto items-start"
                )}
              >
                <div
                  className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed",
                    isAgent
                      ? "bg-amber-600 text-white rounded-tl-none"
                      : "bg-white text-slate-800 border border-slate-200 shadow-sm rounded-tr-none"
                  )}
                >
                  {msg.text}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 px-1">
                  {msg.time}
                </span>
              </div>
            );
          })}
        </div>

        {/* Message Input */}
        <div className="p-4 bg-white border-t border-slate-200 shrink-0">
          <div className="flex items-end gap-2 bg-slate-50 border border-slate-200 rounded-2xl p-2 focus-within:border-amber-400 focus-within:ring-1 focus-within:ring-amber-400 transition-all">
            <Button variant="ghost" size="icon" className="text-slate-400 shrink-0 rounded-xl hover:bg-slate-200 h-10 w-10">
              <Smile className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-slate-400 shrink-0 rounded-xl hover:bg-slate-200 h-10 w-10">
              <ImageIcon className="w-5 h-5" />
            </Button>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب رسالتك هنا..."
              className="flex-1 bg-transparent border-none focus:ring-0 resize-none max-h-32 min-h-[40px] text-sm py-2 px-2 custom-scrollbar outline-none text-slate-700"
              rows={1}
            />
            <Button onClick={handleSendMessage} className="shrink-0 rounded-xl bg-amber-600 hover:bg-amber-700 text-white h-10 w-10 p-0 flex items-center justify-center">
              <Send className="w-4 h-4 rtl:-scale-x-100" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
