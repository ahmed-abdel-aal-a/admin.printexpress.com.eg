"use client";

import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function ChatWidgetSettings() {
  const [isMessageEnabled, setIsMessageEnabled] = useState(true);
  const [messageText, setMessageText] = useState("مرحباً بك! كيف يمكننا مساعدتك اليوم؟");
  const [displayLocation, setDisplayLocation] = useState("chat_only"); // chat_only or chat_and_faq

  return (
    <div className="max-w-2xl space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <div>
          <h2 className="text-lg font-bold text-slate-800">الرسالة الترحيبية الثابتة</h2>
          <p className="text-sm text-slate-500 mt-1">
            قم بإعداد الرسالة التي تظهر للعملاء عند فتح نافذة المحادثة في المتجر.
          </p>
        </div>

        <div className="space-y-5 border-t border-slate-100 pt-5">
          {/* Toggle Enable/Disable */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base font-semibold text-slate-800">تفعيل الرسالة الثابتة</Label>
              <p className="text-sm text-slate-500">إظهار الرسالة تلقائياً عند فتح المحادثة.</p>
            </div>
            <button
              type="button"
              onClick={() => setIsMessageEnabled(!isMessageEnabled)}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                isMessageEnabled ? "bg-amber-600" : "bg-slate-200"
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  isMessageEnabled ? "-translate-x-5" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* Message Content */}
          <div className={`space-y-4 transition-opacity duration-200 ${isMessageEnabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
            <div className="space-y-2">
              <Label htmlFor="welcome-msg" className="font-semibold text-slate-700">نص الرسالة</Label>
              <Textarea
                id="welcome-msg"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="اكتب رسالتك الترحيبية هنا..."
                className="resize-none h-24 bg-slate-50 focus:bg-white"
              />
            </div>

            {/* Display Location */}
            <div className="space-y-3">
              <Label className="font-semibold text-slate-700">مكان العرض</Label>
              <div className="flex flex-col gap-3 sm:flex-row">
                <label className="flex items-center gap-3 p-3 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50 transition-colors flex-1">
                  <input
                    type="radio"
                    name="displayLocation"
                    value="chat_only"
                    checked={displayLocation === "chat_only"}
                    onChange={(e) => setDisplayLocation(e.target.value)}
                    className="w-4 h-4 text-amber-600 border-slate-300 focus:ring-amber-500"
                  />
                  <span className="text-sm font-medium text-slate-700">في المحادثة فقط</span>
                </label>
                
                <label className="flex items-center gap-3 p-3 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50 transition-colors flex-1">
                  <input
                    type="radio"
                    name="displayLocation"
                    value="chat_and_faq"
                    checked={displayLocation === "chat_and_faq"}
                    onChange={(e) => setDisplayLocation(e.target.value)}
                    className="w-4 h-4 text-amber-600 border-slate-300 focus:ring-amber-500"
                  />
                  <span className="text-sm font-medium text-slate-700">في المحادثة والأسئلة الشائعة</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 flex justify-end">
          <Button className="bg-amber-600 hover:bg-amber-700 text-white px-8 rounded-xl shadow-sm">
            حفظ التغييرات
          </Button>
        </div>
      </div>
    </div>
  );
}
