"use client";

import { useState } from "react";
import { Plus, Edit2, Trash2, ChevronDown, ChevronUp, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

const INITIAL_FAQS = [
  {
    id: "sec-1",
    title: "الشحن والتوصيل",
    questions: [
      { id: "q-1", q: "كم تستغرق مدة التوصيل؟", a: "يستغرق التوصيل عادة من 2 إلى 5 أيام عمل داخل المملكة." },
      { id: "q-2", q: "هل يتوفر شحن دولي؟", a: "نعم، نوفر خدمة الشحن الدولي لجميع دول الخليج." },
    ]
  },
  {
    id: "sec-2",
    title: "الاسترجاع والاستبدال",
    questions: [
      { id: "q-3", q: "ما هي سياسة الاسترجاع؟", a: "يمكنك استرجاع المنتج خلال 14 يوماً من تاريخ الاستلام بشرط أن يكون في حالته الأصلية." }
    ]
  }
];

export default function FAQManager() {
  const [sections, setSections] = useState(INITIAL_FAQS);
  const [expandedSection, setExpandedSection] = useState<string | null>("sec-1");

  const handleAddSection = () => {
    const title = window.prompt("أدخل عنوان القسم الجديد:");
    if (title) {
      setSections([...sections, {
        id: `sec-${Date.now()}`,
        title,
        questions: []
      }]);
    }
  };

  const handleEditSection = (id: string, currentTitle: string) => {
    const title = window.prompt("تعديل عنوان القسم:", currentTitle);
    if (title && title !== currentTitle) {
      setSections(sections.map(s => s.id === id ? { ...s, title } : s));
    }
  };

  const handleDeleteSection = (id: string) => {
    if (window.confirm("هل أنت متأكد من حذف هذا القسم؟")) {
      setSections(sections.filter(s => s.id !== id));
      if (expandedSection === id) setExpandedSection(null);
    }
  };

  const handleAddQuestion = (sectionId: string) => {
    const q = window.prompt("أدخل السؤال الجديد:");
    if (!q) return;
    const a = window.prompt("أدخل الإجابة:");
    if (!a) return;

    setSections(sections.map(s => {
      if (s.id === sectionId) {
        return {
          ...s,
          questions: [...s.questions, { id: `q-${Date.now()}`, q, a }]
        };
      }
      return s;
    }));
  };

  const handleEditQuestion = (sectionId: string, questionId: string, currentQ: string, currentA: string) => {
    const q = window.prompt("تعديل السؤال:", currentQ);
    if (!q) return;
    const a = window.prompt("تعديل الإجابة:", currentA);
    if (!a) return;

    setSections(sections.map(s => {
      if (s.id === sectionId) {
        return {
          ...s,
          questions: s.questions.map(question => 
            question.id === questionId ? { ...question, q, a } : question
          )
        };
      }
      return s;
    }));
  };

  const handleDeleteQuestion = (sectionId: string, questionId: string) => {
    if (window.confirm("هل أنت متأكد من حذف هذا السؤال؟")) {
      setSections(sections.map(s => {
        if (s.id === sectionId) {
          return {
            ...s,
            questions: s.questions.filter(question => question.id !== questionId)
          };
        }
        return s;
      }));
    }
  };

  return (
    <div className="max-w-4xl space-y-6 pb-12">
      <div className="flex justify-between items-center bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-lg font-bold text-slate-800">أقسام الأسئلة الشائعة</h2>
          <p className="text-sm text-slate-500 mt-1">
            قم بإدارة الأقسام والأسئلة التي تظهر للعملاء في واجهة المتجر بشكل تلقائي.
          </p>
        </div>
        <Button onClick={handleAddSection} className="bg-amber-600 hover:bg-amber-700 text-white gap-2 rounded-xl shadow-md">
          <Plus className="w-4 h-4" />
          <span>إضافة قسم جديد</span>
        </Button>
      </div>

      <div className="space-y-4">
        {sections.map((section) => {
          const isExpanded = expandedSection === section.id;
          return (
            <div key={section.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm transition-all duration-200 hover:border-slate-300">
              {/* Section Header */}
              <div 
                className="flex items-center justify-between p-4 cursor-pointer bg-slate-50/50"
                onClick={() => setExpandedSection(isExpanded ? null : section.id)}
              >
                <div className="flex items-center gap-3">
                  <div className="text-slate-400 cursor-grab hover:text-slate-600">
                    <GripVertical className="w-5 h-5" />
                  </div>
                  <h3 className="font-semibold text-slate-800">{section.title}</h3>
                  <span className="bg-white border border-slate-200 px-2.5 py-0.5 rounded-full text-xs font-medium text-slate-600 shadow-sm">
                    {section.questions.length} أسئلة
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="text-slate-400 hover:text-blue-600 h-8 w-8" onClick={(e) => { e.stopPropagation(); handleEditSection(section.id, section.title); }}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-600 h-8 w-8" onClick={(e) => { e.stopPropagation(); handleDeleteSection(section.id); }}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                  <div className="w-px h-6 bg-slate-200 mx-1" />
                  <Button variant="ghost" size="icon" className="text-slate-400 h-8 w-8">
                    {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </Button>
                </div>
              </div>

              {/* Questions List */}
              {isExpanded && (
                <div className="p-4 border-t border-slate-100 bg-white space-y-3">
                  {section.questions.map((item, idx) => (
                    <div key={item.id} className="flex items-start gap-4 p-4 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                       <div className="text-slate-400 mt-1 cursor-grab hover:text-slate-600 shrink-0">
                          <GripVertical className="w-4 h-4" />
                        </div>
                        <div className="flex-1 space-y-2">
                          <div>
                            <span className="text-xs font-bold text-amber-600 uppercase tracking-wider mb-1 block">السؤال</span>
                            <p className="text-sm font-semibold text-slate-800">{item.q}</p>
                          </div>
                          <div>
                            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-1 block">الإجابة</span>
                            <p className="text-sm text-slate-600 leading-relaxed">{item.a}</p>
                          </div>
                        </div>
                        <div className="flex flex-col gap-1 shrink-0">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-blue-600" onClick={() => handleEditQuestion(section.id, item.id, item.q, item.a)}>
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-red-600" onClick={() => handleDeleteQuestion(section.id, item.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                    </div>
                  ))}
                  
                  <Button onClick={() => handleAddQuestion(section.id)} variant="outline" className="w-full mt-2 border-dashed border-2 text-slate-500 hover:text-amber-700 hover:border-amber-300 hover:bg-amber-50 flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    إضافة سؤال جديد
                  </Button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
